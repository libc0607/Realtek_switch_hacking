/*
 * Copyright (C) 2009 Realtek Semiconductor Corp.
 * All Rights Reserved.
 *
 * This program is the proprietary software of Realtek Semiconductor
 * Corporation and/or its licensors, and only be used, duplicated,
 * modified or distributed under the authorized license from Realtek.
 *
 * ANY USE OF THE SOFTWARE OTHER THAN AS AUTHORIZED UNDER
 * THIS LICENSE OR COPYRIGHT LAW IS PROHIBITED.
 *
 * $Revision: 52260 $
 * $Date: 2014-10-17 14:14:26 +0800 (Fri, 17 Oct 2014) $
 *
 * Purpose : Definition of VLAN API
 *
 * Feature : The file includes the following modules and sub-modules
 *           (1) Vlan table configure and modification
 *           (2) Accept frame type
 *           (3) Vlan ingress/egress filter
 *           (4) Port based and protocol based vlan
 *           (5) TPID configuration
 *           (6) Ingress tag handling
 *           (7) Tag format handling
 *
 */

/*
 * Include Files
 */
#include <common/rt_error.h>
#include <common/util/rt_util.h>
#include <dal/dal_mgmt.h>
#include <rtk/default.h>
#include <rtk/vlan.h>

/*
 * Symbol Definition
 */

/*
 * Data Declaration
 */

/*
 * Macro Declaration
 */

/*
 * Function Declaration
 */

/* Function Name:
 *      rtk_vlan_init
 * Description:
 *      Initialize vlan module of the specified device.
 * Input:
 *      unit - unit id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID - invalid unit id
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      Must initialize vlan module before calling any vlan APIs.
 */
int32
rtk_vlan_init(uint32 unit)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_init(unit);
} /* end of rtk_vlan_init */

/* Module Name    : Vlan                                  */
/* Sub-module Name: Vlan table configure and modification */

/* Function Name:
 *      rtk_vlan_create
 * Description:
 *      Create the vlan in the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id to be created
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID    - invalid unit id
 *      RT_ERR_NOT_INIT   - The module is not initial
 *      RT_ERR_VLAN_VID   - invalid vid
 *      RT_ERR_VLAN_EXIST - vlan is exist
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) Default FID and STG is assigned after vlan creation.
 *      (3) Default FID is equal with VID (IVL mode) and default STG is CIST.
 *      (4) FID and STG can be reassigned later by following APIs.
 *          - rtk_vlan_fid_set
 *          - rtk_vlan_stg_set
 */
int32
rtk_vlan_create(uint32 unit, rtk_vlan_t vid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_create(unit, vid);
} /* end of rtk_vlan_create */

/* Function Name:
 *      rtk_vlan_destroy
 * Description:
 *      Destroy the vlan in the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id to be destroyed
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 */
int32
rtk_vlan_destroy(uint32 unit, rtk_vlan_t vid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_destroy(unit, vid);
} /* end of rtk_vlan_destroy */

/* Function Name:
 *      rtk_vlan_destroyAll
 * Description:
 *      Destroy all vlans except default vlan in the specified device.
 * Input:
 *      unit                 - unit id
 *      restore_default_vlan - keep and restore default vlan id or not?
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      The restore argument is permit following value:
 *      - 0: remove default vlan
 *      - 1: restore default vlan
 */
int32
rtk_vlan_destroyAll(uint32 unit, uint32 restore_default_vlan)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_destroyAll(unit, restore_default_vlan);
} /* end of rtk_vlan_destroyAll */

/* Function Name:
 *      rtk_vlan_fid_get
 * Description:
 *      Get the filtering database id of the vlan from the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 * Output:
 *      pFid - pointer buffer of filtering database id
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) FID is useless when running in IVL mode.
 *      (3) The API should only be used when running in SVL mode.
 *      (4) FID instance also represents STG in 8390 and 8380
 */
int32
rtk_vlan_fid_get(uint32 unit, rtk_vlan_t vid, rtk_fid_t *pFid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_fid_get(unit, vid, pFid);
} /* end of rtk_vlan_fid_get */

/* Function Name:
 *      rtk_vlan_fid_set
 * Description:
 *      Set the filter id of the vlan to the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 *      fid  - filter id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_OUT_OF_RANGE         - input parameter out of range
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) You don't need to care fid when you use the IVL mode.
 *      (3) The API should be used for SVL mode.
 *      (4) FID instance also represents STG in 8390 and 8380
 */
int32
rtk_vlan_fid_set(uint32 unit, rtk_vlan_t vid, rtk_fid_t fid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_fid_set(unit, vid, fid);
} /* end of rtk_vlan_fid_set */

/* Function Name:
 *      rtk_vlan_port_add
 * Description:
 *      Add one vlan member to the specified device.
 * Input:
 *      unit     - unit id
 *      vid      - vlan id
 *      port     - port id for add
 *      is_untag - untagged or tagged member
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_PORT_ID              - invalid port id
 *      RT_ERR_VLAN_PORT_MBR_EXIST  - member port exist in the specified vlan
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_OUT_OF_RANGE         - input parameter out of range
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) The valid value of is_untag are {0: tagged, 1: untagged}
 */
int32
rtk_vlan_port_add(uint32 unit, rtk_vlan_t vid, rtk_port_t port, uint32 is_untag)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_port_add(unit, vid, phy_port, is_untag);
    }
#else
    return RT_MAPPER(unit)->vlan_port_add(unit, vid, port, is_untag);
#endif
} /* end of rtk_vlan_port_add */

/* Function Name:
 *      rtk_vlan_port_del
 * Description:
 *      Delete one vlan member from the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 *      port - port id for delete
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_PORT_ID              - invalid port id
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 */
int32
rtk_vlan_port_del(uint32 unit, rtk_vlan_t vid, rtk_port_t port)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_port_del(unit, vid, phy_port);
    }
#else
    return RT_MAPPER(unit)->vlan_port_del(unit, vid, port);
#endif
} /* end of rtk_vlan_port_del */

/* Function Name:
 *      rtk_vlan_port_get
 * Description:
 *      Get the vlan members from the specified device.
 * Input:
 *      unit             - unit id
 *      vid              - vlan id
 * Output:
 *      pMember_portmask - pointer buffer of member ports
 *      pUntag_portmask  - pointer buffer of untagged member ports
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 */
int32
rtk_vlan_port_get(
    uint32         unit,
    rtk_vlan_t     vid,
    rtk_portmask_t *pMember_portmask,
    rtk_portmask_t *pUntag_portmask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32   ret;
    rtk_portmask_t  temp_memberPortmask, temp_untagPortmask;

    if ((ret = RT_MAPPER(unit)->vlan_port_get(unit, vid, &temp_memberPortmask, &temp_untagPortmask)) != RT_ERR_OK)
        return ret;
    *pMember_portmask = PHYSICAL_PORTMASK_TO_RTK_PORTMASK(unit, temp_memberPortmask);
    *pUntag_portmask = PHYSICAL_PORTMASK_TO_RTK_PORTMASK(unit, temp_untagPortmask);
    return ret;
    }
#else
    return RT_MAPPER(unit)->vlan_port_get(unit, vid, pMember_portmask, pUntag_portmask);
#endif
} /* end of rtk_vlan_port_get */

/* Function Name:
 *      rtk_vlan_port_set
 * Description:
 *      Replace the vlan members in the specified device.
 * Input:
 *      unit             - unit id
 *      vid              - vlan id
 *      pMember_portmask - member ports
 *      pUntag_portmask  - untagged member ports
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) Replace with new specified VLAN member regardless of original setting.
 */
int32
rtk_vlan_port_set(
    uint32         unit,
    rtk_vlan_t     vid,
    rtk_portmask_t *pMember_portmask,
    rtk_portmask_t *pUntag_portmask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    rtk_portmask_t  temp_memberPortmask, temp_untagPortmask;

    temp_memberPortmask = RTK_PORTMASK_TO_PHYSICAL_PORTMASK(unit, *pMember_portmask);
    temp_untagPortmask = RTK_PORTMASK_TO_PHYSICAL_PORTMASK(unit, *pUntag_portmask);
    return RT_MAPPER(unit)->vlan_port_set(unit, vid, &temp_memberPortmask, &temp_untagPortmask);
    }
#else
    return RT_MAPPER(unit)->vlan_port_set(unit, vid, pMember_portmask, pUntag_portmask);
#endif
} /* end of rtk_vlan_port_set */

/* Function Name:
 *      rtk_vlan_stg_get
 * Description:
 *      Get spanning tree group instance of the vlan from the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 * Output:
 *      pStg - pointer buffer of spanning tree group instance
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) STG instance also represents FID in 8390 and 8380
 */
int32
rtk_vlan_stg_get(uint32 unit, rtk_vlan_t vid, rtk_stg_t *pStg)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_stg_get(unit, vid, pStg);
} /* end of rtk_vlan_stg_get */

/* Function Name:
 *      rtk_vlan_stg_set
 * Description:
 *      Set spanning tree group instance of the vlan to the specified device.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 *      stg  - spanning tree group instance
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_MSTI                 - invalid msti
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) STG instance also represents FID in 8390 and 8380
 */
int32
rtk_vlan_stg_set(uint32 unit, rtk_vlan_t vid, rtk_stg_t stg)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_stg_set(unit, vid, stg);
} /* end of rtk_vlan_stg_set */

/* Function Name:
 *      rtk_vlan_l2UcastLookupMode_get
 * Description:
 *      Get L2 lookup mode for L2 unicast traffic.
 * Input:
 *      unit  - unit id
 *      vid   - vlan id
 * Output:
 *      pMode - lookup mode
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Each VLAN can have its own lookup mode for L2 unicast traffic
 */
int32
rtk_vlan_l2UcastLookupMode_get(uint32 unit, rtk_vlan_t vid, rtk_l2_ucastLookupMode_t *pMode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_l2UcastLookupMode_get(unit, vid, pMode);
} /* end of rtk_vlan_l2UcastLookupMode_get */

/* Function Name:
 *      rtk_vlan_l2UcastLookupMode_set
 * Description:
 *      Set L2 lookup mode for L2 unicast traffic.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 *      mode - lookup mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_INPUT                - Invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Each VLAN can have its own lookup mode for L2 unicast traffic
 */
int32
rtk_vlan_l2UcastLookupMode_set(uint32 unit, rtk_vlan_t vid, rtk_l2_ucastLookupMode_t mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_l2UcastLookupMode_set(unit, vid, mode);
} /* end of rtk_vlan_l2UcastLookupMode_set */

/* Function Name:
 *      rtk_vlan_l2McastLookupMode_get
 * Description:
 *      Get L2 lookup mode for L2 multicast and IP multicast traffic.
 * Input:
 *      unit  - unit id
 *      vid   - vlan id
 * Output:
 *      pMode - lookup mode
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Each VLAN can have its own lookup mode for L2 and IP mulicast traffic.
 */
int32
rtk_vlan_l2McastLookupMode_get(uint32 unit, rtk_vlan_t vid, rtk_l2_mcastLookupMode_t *pMode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_l2McastLookupMode_get(unit, vid, pMode);
} /* end of rtk_vlan_l2McastLookupMode_get */

/* Function Name:
 *      rtk_vlan_l2McastLookupMode_set
 * Description:
 *      Set L2 lookup mode for L2 multicast and IP multicast traffic.
 * Input:
 *      unit  - unit id
 *      vid   - vlan id
 *      mode  - lookup mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_INPUT                - Invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Each VLAN can have its own lookup mode for L2 and IP mulicast traffic.
 */
int32
rtk_vlan_l2McastLookupMode_set(uint32 unit, rtk_vlan_t vid, rtk_l2_mcastLookupMode_t mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_l2McastLookupMode_set(unit, vid, mode);
} /* end of rtk_vlan_l2McastLookupMode_set */

/* Function Name:
 *      rtk_vlan_profileIdx_get
 * Description:
 *      Get VLAN profile index of specified VLAN.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 * Output:
 *      pIdx - VLAN profile index
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Each VLAN can bind to a VLAN profile.
 */
int32
rtk_vlan_profileIdx_get(uint32 unit, rtk_vlan_t vid, uint32 *pIdx)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_profileIdx_get(unit, vid, pIdx);
} /* end of rtk_vlan_profileIdx_get */

/* Function Name:
 *      rtk_vlan_profileIdx_set
 * Description:
 *      Set VLAN profile index of specified VLAN.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 *      idx  - VLAN profile index
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - specified vlan entry not found
 *      RT_ERR_OUT_OF_RANGE         - profile index is out of range
 * Applicable:
 *      8390, 8380
 * Note:
 *      Each VLAN can bind to a VLAN profile.
 */
int32
rtk_vlan_profileIdx_set(uint32 unit, rtk_vlan_t vid, uint32 idx)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_profileIdx_set(unit, vid, idx);
} /* end of rtk_vlan_profileIdx_set */

/* Module Name     : vlan         */
/* Sub-module Name : vlan profile */

/* Function Name:
 *      rtk_vlan_profile_get
 * Description:
 *      Get specific VLAN profile.
 * Input:
 *      unit     - unit id
 *      idx      - VLAN profile index
 * Output:
 *      pProfile - VLAN profile configuration
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - profile index is out of range
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_profile_get(uint32 unit, uint32 idx, rtk_vlan_profile_t *pProfile)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_profile_get(unit, idx, pProfile);
} /* end of rtk_vlan_profile_get */

/* Function Name:
 *      rtk_vlan_profile_set
 * Description:
 *      Set specific VLAN profile.
 * Input:
 *      unit     - unit id
 *      idx      - VLAN profile index
 *      pProfile - VLAN profile configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - profile index is out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_profile_set(uint32 unit, uint32 idx, rtk_vlan_profile_t *pProfile)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_profile_set(unit, idx, pProfile);
} /* end of rtk_vlan_profile_set */

/* Module Name     : vlan           */
/* Sub-module Name : vlan attribute */

/* Module Name     : vlan                */
/* Sub-module Name : vlan port attribute */

/* Function Name:
 *      rtk_vlan_portAcceptFrameType_get
 * Description:
 *      Get vlan accept frame type of the port from the specified device.
 * Input:
 *      unit               - unit id
 *      port               - port id
 * Output:
 *      pAccept_frame_type - pointer buffer of accept frame type
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The accept frame type as following:
 *          - ACCEPT_FRAME_TYPE_ALL
 *          - ACCEPT_FRAME_TYPE_TAG_ONLY
 *          - ACCEPT_FRAME_TYPE_UNTAG_ONLY
 *      (2) The API is used for 802.1Q tagged  and if you want to get the 802.1ad
 *          accept frame type, please use rtk_vlan_portOuterAcceptFrameType_get.
 */
int32
rtk_vlan_portAcceptFrameType_get(
    uint32                     unit,
    rtk_port_t                 port,
    rtk_vlan_acceptFrameType_t *pAccept_frame_type)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portAcceptFrameType_get(unit, phy_port, pAccept_frame_type);
    }
#else
    return RT_MAPPER(unit)->vlan_portAcceptFrameType_get(unit, port, pAccept_frame_type);
#endif
} /* end of rtk_vlan_portAcceptFrameType_get */

/* Function Name:
 *      rtk_vlan_portAcceptFrameType_set
 * Description:
 *      Set vlan accept frame type of the port to the specified device.
 * Input:
 *      unit              - unit id
 *      port              - port id
 *      accept_frame_type - accept frame type
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID                - invalid unit id
 *      RT_ERR_NOT_INIT               - The module is not initial
 *      RT_ERR_PORT_ID                - invalid port id
 *      RT_ERR_VLAN_ACCEPT_FRAME_TYPE - invalid accept frame type
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      (1) The accept frame type as following:
 *          - ACCEPT_FRAME_TYPE_ALL
 *          - ACCEPT_FRAME_TYPE_TAG_ONLY
 *          - ACCEPT_FRAME_TYPE_UNTAG_ONLY
 *      (2) The API is used for 802.1Q tagged  and if you want to set the 802.1ad
 *          accept frame type, please use rtk_vlan_portOuterAcceptFrameType_set.
 */
int32
rtk_vlan_portAcceptFrameType_set(
    uint32                     unit,
    rtk_port_t                 port,
    rtk_vlan_acceptFrameType_t accept_frame_type)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portAcceptFrameType_set(unit, phy_port, accept_frame_type);
    }
#else
    return RT_MAPPER(unit)->vlan_portAcceptFrameType_set(unit, port, accept_frame_type);
#endif
} /* end of rtk_vlan_portAcceptFrameType_set */

/* Function Name:
 *      rtk_vlan_portOuterAcceptFrameType_get
 * Description:
 *      Get accept frame type of outer tag on specified port.
 * Input:
 *      unit               - unit id
 *      port               - port id
 * Output:
 *      pAccept_frame_type - pointer to accept frame type
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Accept frame type is as following:
 *      - ACCEPT_FRAME_TYPE_ALL
 *      - ACCEPT_FRAME_TYPE_TAG_ONLY
 *      - ACCEPT_FRAME_TYPE_UNTAG_ONLY
 */
int32
rtk_vlan_portOuterAcceptFrameType_get(
    uint32                      unit,
    rtk_port_t                  port,
    rtk_vlan_acceptFrameType_t  *pAccept_frame_type)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portOuterAcceptFrameType_get(unit, phy_port, pAccept_frame_type);
    }
#else
    return RT_MAPPER(unit)->vlan_portOuterAcceptFrameType_get(unit, port, pAccept_frame_type);
#endif
} /* end of rtk_vlan_portOuterAcceptFrameType_get */

/* Function Name:
 *      rtk_vlan_portOuterAcceptFrameType_set
 * Description:
 *      Set accept frame type of outer tag on specified port.
 * Input:
 *      unit              - unit id
 *      port              - port id
 *      accept_frame_type - accept frame type
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID                - invalid unit id
 *      RT_ERR_NOT_INIT               - The module is not initial
 *      RT_ERR_PORT_ID                - invalid port id
 *      RT_ERR_VLAN_ACCEPT_FRAME_TYPE - invalid accept frame type
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Accept frame type is as following:
 *      - ACCEPT_FRAME_TYPE_ALL
 *      - ACCEPT_FRAME_TYPE_TAG_ONLY
 *      - ACCEPT_FRAME_TYPE_UNTAG_ONLY
 */
int32
rtk_vlan_portOuterAcceptFrameType_set(
    uint32                      unit,
    rtk_port_t                  port,
    rtk_vlan_acceptFrameType_t  accept_frame_type)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portOuterAcceptFrameType_set(unit, phy_port, accept_frame_type);
    }
#else
    return RT_MAPPER(unit)->vlan_portOuterAcceptFrameType_set(unit, port, accept_frame_type);
#endif
} /* end of rtk_vlan_portOuterAcceptFrameType_set */

/* Function Name:
 *      rtk_vlan_vlanFunctionEnable_get
 * Description:
 *      Get the VLAN enable status of the specified device.
 * Input:
 *      unit    - unit id
 * Output:
 *      pEnable - pointer buffer of status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389
 * Note:
 *      The status of vlan function is as following:
 *      - DISABLED
 *      - ENABLED
 */
int32
rtk_vlan_vlanFunctionEnable_get(uint32 unit, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_vlanFunctionEnable_get(unit, pEnable);
} /* end of rtk_vlan_vlanFunctionEnable_get */

/* Function Name:
 *      rtk_vlan_vlanFunctionEnable_set
 * Description:
 *      Set the VLAN enable status of the specified device.
 * Input:
 *      unit   - unit id
 *      enable - enable status
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8389
 * Note:
 *      The status of vlan function is as following:
 *      - DISABLED
 *      - ENABLED
 */
int32
rtk_vlan_vlanFunctionEnable_set(uint32 unit, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_vlanFunctionEnable_set(unit, enable);
} /* end of rtk_vlan_vlanFunctionEnable_set */

/* Module Name    : Vlan                       */
/* Sub-module Name: Vlan ingress/egress filter */

/* Function Name:
 *      rtk_vlan_igrFilterEnable_get
 * Description:
 *      Get vlan ingress filter status from the specified device.
 * Input:
 *      unit        - unit id
 * Output:
 *      pIgr_filter - pointer buffer of ingress filter status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389
 * Note:
 *      The status of vlan ingress filter is as following:
 *      - DISABLED
 *      - ENABLED
 */
int32
rtk_vlan_igrFilterEnable_get(uint32 unit, rtk_enable_t *pIgr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrFilterEnable_get(unit, pIgr_filter);
} /* end of rtk_vlan_igrFilterEnable_get */

/* Function Name:
 *      rtk_vlan_igrFilterEnable_set
 * Description:
 *      Set vlan ingress filter status to the specified device.
 * Input:
 *      unit       - unit id
 *      igr_filter - ingress filter configure
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8389
 * Note:
 *      (1) If the chip is per system configuration, set any port will apply to
 *          whole device. like RTL8329/RTL8389 chip.
 *      (2) The status of vlan ingress filter is as following:
 *          - DISABLED
 *          - ENABLED
 */
int32
rtk_vlan_igrFilterEnable_set(uint32 unit, rtk_enable_t igr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrFilterEnable_set(unit, igr_filter);
} /* end of rtk_vlan_igrFilterEnable_set */

/* Function Name:
 *      rtk_vlan_portIgrFilterEnable_get
 * Description:
 *      Get vlan ingress filter status of the port from the specified device.
 * Input:
 *      unit        - unit id
 *      port        - port id
 * Output:
 *      pIgr_filter - pointer buffer of ingress filter status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) The status of ingress filter is as following:
 *          - DISABLED
 *          - ENABLED
 *      (2) For 8390 and 8380, the function is backward compatible RTL8328 APIs. 
 *          The 'drop' action is return enable; 'forward' or 'trap' action is return disable.
 */
int32
rtk_vlan_portIgrFilterEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pIgr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrFilterEnable_get(unit, port, pIgr_filter);
} /* end of rtk_vlan_portIgrFilterEnable_get */

/* Function Name:
 *      rtk_vlan_portIgrFilterEnable_set
 * Description:
 *      Set vlan ingress filter status of the port to the specified device.
 * Input:
 *      unit       - unit id
 *      port       - port id
 *      igr_filter - ingress filter configure
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) The status of vlan ingress filter is as following:
 *          - DISABLED
 *          - ENABLED
 *      (2) For 8390 and 8380, the function is backward compatible RTL8328 APIs. 
 *          Congiure enable is mapped to 'drop' action; disable is mapped to 'forward' action.
 */
int32
rtk_vlan_portIgrFilterEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t igr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrFilterEnable_set(unit, port, igr_filter);
} /* end of rtk_vlan_portIgrFilterEnable_set */

/* Function Name:
 *      rtk_vlan_portEgrFilterEnable_get
 * Description:
 *      Get enable status of egress filtering on specified port.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status of egress filtering
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrFilterEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEgr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrFilterEnable_get(unit, phy_port, pEgr_filter);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrFilterEnable_get(unit, port, pEgr_filter);
#endif
} /* end of rtk_vlan_portEgrFilterEnable_get */

/* Function Name:
 *      rtk_vlan_portEgrFilterEnable_set
 * Description:
 *      Set enable status of egress filtering on specified port.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of egress filtering
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrFilterEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t egr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrFilterEnable_set(unit, phy_port, egr_filter);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrFilterEnable_set(unit, port, egr_filter);
#endif
} /* end of rtk_vlan_portEgrFilterEnable_set */

/* Function Name:
 *      rtk_vlan_portIgrFilter_get
 * Description:
 *      Get vlan ingress filter configuration of the port from the specified device.
 * Input:
 *      unit        - unit id
 *      port        - port id
 * Output:
 *      pIgr_filter - pointer buffer of ingress filter configuration
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      VLAN ingress filter checks if the packet's ingress port belongs to the given(forwarding) VLAN
 *      when the packet comes in the switch.
 */
int32
rtk_vlan_portIgrFilter_get(uint32 unit, rtk_port_t port, rtk_vlan_ifilter_t *pIgr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrFilter_get(unit, phy_port, pIgr_filter);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrFilter_get(unit, port, pIgr_filter);
#endif
} /* end of rtk_vlan_portIgrFilter_get */

/* Function Name:
 *      rtk_vlan_portIgrFilter_set
 * Description:
 *      Set vlan ingress filter configuration of the port from the specified device.
 * Input:
 *      unit       - unit id
 *      port       - port id
 *      igr_filter - ingress filter configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      VLAN ingress filter checks if the packet's ingress port belongs to the given(forwarding) VLAN
 *      when the packet comes in the switch.
 */
int32
rtk_vlan_portIgrFilter_set(uint32 unit, rtk_port_t port, rtk_vlan_ifilter_t igr_filter)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrFilter_set(unit, phy_port, igr_filter);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrFilter_set(unit, port, igr_filter);
#endif
} /* end of rtk_vlan_portIgrFilter_set */

/* Function Name:
 *      rtk_vlan_mcastLeakyEnable_get
 * Description:
 *      Get vlan egress leaky status of the system from the specified device.
 * Input:
 *      unit   - unit id
 * Output:
 *      pLeaky - pointer buffer of vlan leaky of egress
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389, 8390, 8380
 * Note:
 *      (1) Enable leaky function to allow known L2/IP multicast traffic to across VLAN.
 *          That is, egress VLAN filtering is bypassed by known L2/IP multicast traffic.
 *      (2) The status of vlan egress multicast leaky is as following:
 *          - DISABLED
 *          - ENABLED
 */
int32
rtk_vlan_mcastLeakyEnable_get(uint32 unit, rtk_enable_t *pLeaky)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_mcastLeakyEnable_get(unit, pLeaky);
} /* end of rtk_vlan_mcastLeakyEnable_get */

/* Function Name:
 *      rtk_vlan_mcastLeakyEnable_set
 * Description:
 *      Set vlan egress leaky configure of the system to the specified device.
 * Input:
 *      unit  - unit id
 *      leaky - vlan leaky of egress
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8389, 8390, 8380
 * Note:
 *      (1) Enable leaky function to allow known L2/IP MULTICAST traffic to across VLAN.
 *          That is, egress VLAN filtering is bypassed by known L2/IP multicast traffic.
 *      (2) The status of vlan egress multicast leaky is as following:
 *          - DISABLED
 *          - ENABLED
 */
int32
rtk_vlan_mcastLeakyEnable_set(uint32 unit, rtk_enable_t leaky)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_mcastLeakyEnable_set(unit, leaky);
} /* end of rtk_vlan_mcastLeakyEnable_set */

/* Module Name    : Vlan                               */
/* Sub-module Name: Port based and protocol based vlan */

/* Function Name:
 *      rtk_vlan_mcastLeakyPortEnable_get
 * Description:
 *      Get vlan egress leaky status of the port from the specified device.
 * Input:
 *      unit   - unit id
 *      port   - port id
 * Output:
 *      pLeaky - pointer buffer of vlan leaky of egress
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389, 8328
 * Note:
 *      The status of vlan egress multicast leaky is as following:
 *      - DISABLED
 *      - ENABLED
 */
int32
rtk_vlan_mcastLeakyPortEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pLeaky)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_mcastLeakyPortEnable_get(unit, port, pLeaky);
} /* end of rtk_vlan_mcastLeakyPortEnable_get */

/* Function Name:
 *      rtk_vlan_mcastLeakyPortEnable_set
 * Description:
 *      Set vlan egress leaky configure of the port to the specified device.
 * Input:
 *      unit  - unit id
 *      port  - port id
 *      leaky - vlan leaky of egress
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8389, 8328
 * Note:
 *      (1) egress vlan leaky configuration is apply to L2/IP multicast packet only,
 *          no apply to unicast.
 *      (2) If the chip is per system configuration, set any port will apply
 *          to whole device.
 *      (3) The status of vlan egress multicast leaky is as following:
 *          - DISABLED
 *          - ENABLED
 */
int32
rtk_vlan_mcastLeakyPortEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t leaky)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_mcastLeakyPortEnable_set(unit, port, leaky);
} /* end of rtk_vlan_mcastLeakyPortEnable_set */

/* Module Name    : Vlan                               */
/* Sub-module Name: Port based and protocol based vlan */

/* Function Name:
 *      rtk_vlan_portPvidMode_get
 * Description:
 *      Get the configuration of inner port-based VLAN mode.
 * Input:
 *      unit  - unit id
 *      port  - port id
 * Output:
 *      pMode - pointer to inner port-based VLAN mode configuration
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Inner port-based VLAN can apply on different tag format, refer to enum rtk_vlan_pbVlan_mode_t.
 */
int32
rtk_vlan_portPvidMode_get(uint32 unit, rtk_port_t port, rtk_vlan_pbVlan_mode_t *pMode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portPvidMode_get(unit, phy_port, pMode);
    }
#else
    return RT_MAPPER(unit)->vlan_portPvidMode_get(unit, port, pMode);
#endif
} /* end of rtk_vlan_portPvidMode_get */

/* Function Name:
 *      rtk_vlan_portPvidMode_set
 * Description:
 *      Set the configuration of inner port-based VLAN mode.
 * Input:
 *      unit - unit id
 *      port - port id
 *      mode - inner port-based VLAN mode configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Inner port-based VLAN can apply on different tag format, refer to enum rtk_vlan_pbVlan_mode_t.
 */
int32
rtk_vlan_portPvidMode_set(uint32 unit, rtk_port_t port, rtk_vlan_pbVlan_mode_t mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portPvidMode_set(unit, phy_port, mode);
    }
#else
    return RT_MAPPER(unit)->vlan_portPvidMode_set(unit, port, mode);
#endif
} /* end of rtk_vlan_portPvidMode_set */

/* Function Name:
 *      rtk_vlan_portOuterPvidMode_get
 * Description:
 *      Get the configuration of outer port-based VLAN mode.
 * Input:
 *      unit  - unit id
 *      port  - port id
 * Output:
 *      pMode - pointer to outer port-based VLAN mode configuration
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Outer port-based VLAN can apply on different tag format, refer to enum rtk_vlan_pbVlan_mode_t.
 */
int32
rtk_vlan_portOuterPvidMode_get(uint32 unit, rtk_port_t port, rtk_vlan_pbVlan_mode_t *pMode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portOuterPvidMode_get(unit, phy_port, pMode);
    }
#else
    return RT_MAPPER(unit)->vlan_portOuterPvidMode_get(unit, port, pMode);
#endif
} /* end of rtk_vlan_portOuterPvidMode_get */

/* Function Name:
 *      rtk_vlan_portOuterPvidMode_set
 * Description:
 *      Set the configuration of outer port-based VLAN mode.
 * Input:
 *      unit - unit id
 *      port - port id
 *      mode - outer port-based VLAN mode configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Outer port-based VLAN can apply on different tag format, refer to enum rtk_vlan_pbVlan_mode_t.
 */
int32
rtk_vlan_portOuterPvidMode_set(uint32 unit, rtk_port_t port, rtk_vlan_pbVlan_mode_t mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portOuterPvidMode_set(unit, phy_port, mode);
    }
#else
    return RT_MAPPER(unit)->vlan_portOuterPvidMode_set(unit, port, mode);
#endif
} /* end of rtk_vlan_portOuterPvidMode_set */

/* Function Name:
 *      rtk_vlan_portPvid_get
 * Description:
 *      Get port default vlan id from the specified device.
 * Input:
 *      unit  - unit id
 *      port  - port id
 * Output:
 *      pPvid - pointer buffer of port default vlan id
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portPvid_get(uint32 unit, rtk_port_t port, rtk_vlan_t *pPvid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portPvid_get(unit, phy_port, pPvid);
    }
#else
    return RT_MAPPER(unit)->vlan_portPvid_get(unit, port, pPvid);
#endif
} /* end of rtk_vlan_portPvid_get */

/* Function Name:
 *      rtk_vlan_portPvid_set
 * Description:
 *      Set port default vlan id to the specified device.
 * Input:
 *      unit - unit id
 *      port - port id
 *      pvid - port default vlan id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_VLAN_VID - invalid vid
 * Applicable:
 *      8389, 8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portPvid_set(uint32 unit, rtk_port_t port, rtk_vlan_t pvid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portPvid_set(unit, phy_port, pvid);
    }
#else
    return RT_MAPPER(unit)->vlan_portPvid_set(unit, port, pvid);
#endif
} /* end of rtk_vlan_portPvid_set */

/* Function Name:
 *      rtk_vlan_portOuterPvid_get
 * Description:
 *      Get outer port based vlan on specified port.
 * Input:
 *      unit - unit id
 *      port - port id
 * Output:
 *      pVid - pointer to outer port based vlan id
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portOuterPvid_get(uint32 unit, rtk_port_t port, rtk_vlan_t *pPvid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portOuterPvid_get(unit, phy_port, pPvid);
    }
#else
    return RT_MAPPER(unit)->vlan_portOuterPvid_get(unit, port, pPvid);
#endif
} /* end of rtk_vlan_portOuterPvid_get */

/* Function Name:
 *      rtk_vlan_portOuterPvid_set
 * Description:
 *      Set outer port based vlan on specified port.
 * Input:
 *      unit - unit id
 *      port - port id
 *      vid  - outer port based vlan id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_VLAN_VID - invalid vlan id
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portOuterPvid_set(uint32 unit, rtk_port_t port, rtk_vlan_t pvid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portOuterPvid_set(unit, phy_port, pvid);
    }
#else
    return RT_MAPPER(unit)->vlan_portOuterPvid_set(unit, port, pvid);
#endif
} /* end of rtk_vlan_portOuterPvid_set */

/* Function Name:
 *      rtk_vlan_macBasedVlan_get
 * Description:
 *      Get MAC-based vlan.
 * Input:
 *      unit      - unit id
 *      index     - entry index
 * Output:
 *      pValid    - pointer buffer of validate or invalidate the entry
 *      pSmac     - pointer buffer of source mac address
 *      pVid      - pointer buffer of MAC-based VLAN ID
 *      pPriority - pointer buffer of assign internal priority for untag packet
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in MAC-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_macBasedVlan_get(
    uint32      unit,
    uint32      index,
    uint32      *pValid,
    rtk_mac_t   *pSmac,
    rtk_vlan_t  *pVid,
    rtk_pri_t   *pPriority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_macBasedVlan_get(unit, index, pValid, pSmac, pVid, pPriority);
} /* end of rtk_vlan_macBasedVlan_get */

/* Function Name:
 *      rtk_vlan_macBasedVlan_set
 * Description:
 *      Set MAC-based vlan.
 * Input:
 *      unit     - unit id
 *      index    - entry index
 *      valid    - validate or invalidate the entry
 *      pSmac    - source mac address
 *      vid      - MAC-based VLAN ID
 *      priority - assign internal priority for untag packet
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_MAC                  - invalid mac address
 *      RT_ERR_VLAN_VID             - invalid vlan id
 *      RT_ERR_PRIORITY             - invalid priority value
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in MAC-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_macBasedVlan_set(
    uint32      unit,
    uint32      index,
    uint32      valid,
    rtk_mac_t   *pSmac,
    rtk_vlan_t  vid,
    rtk_pri_t   priority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_macBasedVlan_set(unit, index, valid, pSmac, vid, priority);
} /* end of rtk_vlan_macBasedVlan_set */

/* Function Name:
 *      rtk_vlan_macBasedVlanWithMsk_get
 * Description:
 *      Get MAC-based vlan with source MAC address mask.
 * Input:
 *      unit      - unit id
 *      index     - entry index
 * Output:
 *      pValid    - pointer buffer of validate or invalidate the entry
 *      pSmac     - pointer buffer of source mac address
 *      pSmsk     - pointer buffer of source mac address mask
 *      pVid      - pointer buffer of MAC-based VLAN ID
 *      pPriority - pointer buffer of assign internal priority for untag packet
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in MAC-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_macBasedVlanWithMsk_get(
    uint32      unit,
    uint32      index,
    uint32      *pValid,
    rtk_mac_t   *pSmac,
    rtk_mac_t   *pSmsk,
    rtk_vlan_t  *pVid,
    rtk_pri_t   *pPriority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_macBasedVlanWithMsk_get(unit, index, pValid, pSmac, pSmsk, pVid, pPriority);
} /* end of rtk_vlan_macBasedVlanWithMsk_get */

/* Function Name:
 *      rtk_vlan_macBasedVlanWithMsk_set
 * Description:
 *      Set MAC-based vlan with source MAC address mask.
 * Input:
 *      unit     - unit id
 *      index    - entry index
 *      valid    - validate or invalidate the entry
 *      pSmac    - source mac address
 *      pSmsk    - source mac address mask
 *      vid      - MAC-based VLAN ID
 *      priority - assign internal priority for untag packet
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_MAC                  - invalid mac address
 *      RT_ERR_VLAN_VID             - invalid vlan id
 *      RT_ERR_PRIORITY             - invalid priority value
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in MAC-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_macBasedVlanWithMsk_set(
    uint32      unit,
    uint32      index,
    uint32      valid,
    rtk_mac_t   *pSmac,
    rtk_mac_t   *pSmsk,
    rtk_vlan_t  vid,
    rtk_pri_t   priority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_macBasedVlanWithMsk_set(unit, index, valid, pSmac, pSmsk, vid, priority);
} /* end of rtk_vlan_macBasedVlanWithMsk_set */

/* Function Name:
 *      rtk_vlan_macBasedVlanWithPort_get
 * Description:
 *      Get MAC-based vlan with source port ID mask.
 * Input:
 *      unit      - unit id
 *      index     - entry index
 * Output:
 *      pValid    - pointer buffer of validate or invalidate the entry
 *      pSmac     - pointer buffer of source mac address
 *      pSmsk     - pointer buffer of source mac address mask
 *      pPort     - pointer buffer of source port ID
 *      pPmsk     - pointer buffer of source port ID mask
 *      pVid      - pointer buffer of MAC-based VLAN ID
 *      pPriority - pointer buffer of assign internal priority for untag packet
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in MAC-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_macBasedVlanWithPort_get(
    uint32      unit,
    uint32      index,
    uint32      *pValid,
    rtk_mac_t   *pSmac,
    rtk_mac_t   *pSmsk,
    rtk_port_t  *pPort,
    rtk_port_t  *pPmsk,
    rtk_vlan_t  *pVid,
    rtk_pri_t   *pPriority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_macBasedVlanWithPort_get(unit, index, pValid, pSmac, pSmsk, pPort, pPmsk, pVid, pPriority);
} /* end of rtk_vlan_macBasedVlanWithPort_get */

/* Function Name:
 *      rtk_vlan_macBasedVlanWithPort_set
 * Description:
 *      Set MAC-based vlan with source port ID mask.
 * Input:
 *      unit     - unit id
 *      index    - entry index
 *      valid    - validate or invalidate the entry
 *      pSmac    - source mac address
 *      pSmsk    - source mac address mask
 *      port     - source port ID
 *      pmsk     - source port ID mask
 *      vid      - MAC-based VLAN ID
 *      priority - assign internal priority for untag packet
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index or port ID bit-mask is out of range 
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_MAC                  - invalid mac address
 *      RT_ERR_VLAN_VID             - invalid vlan id
 *      RT_ERR_PRIORITY             - invalid priority value
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in MAC-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_macBasedVlanWithPort_set(
    uint32      unit,
    uint32      index,
    uint32      valid,
    rtk_mac_t   *pSmac,
    rtk_mac_t   *pSmsk,
    rtk_port_t  port,
    rtk_port_t  pmsk,
    rtk_vlan_t  vid,
    rtk_pri_t   priority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_macBasedVlanWithPort_set(unit, index, valid, pSmac, pSmsk, port, pmsk, vid, priority);
} /* end of rtk_vlan_macBasedVlanWithPort_set */

/* Function Name:
 *      rtk_vlan_ipSubnetBasedVlan_get
 * Description:
 *      Get IP-Subnet-based vlan.
 * Input:
 *      unit      - unit id
 *      index     - entry index
 * Output:
 *      pValid    - pointer buffer of validate or invalidate the entry
 *      pSip      - pointer buffer of source IP address
 *      pSip_mask - pointer buffer of source IP address mask
 *      pVid      - pointer buffer of VLAN ID
 *      pPriority - pointer buffer of assign internal priority for untag packet
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in IP-Subnet-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_ipSubnetBasedVlan_get(
    uint32      unit,
    uint32      index,
    uint32      *pValid,
    ipaddr_t    *pSip,
    ipaddr_t    *pSip_mask,
    rtk_vlan_t  *pVid,
    rtk_pri_t   *pPriority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_ipSubnetBasedVlan_get(unit, index, pValid, pSip, pSip_mask, pVid, pPriority);
} /* end of rtk_vlan_ipSubnetBasedVlan_get */

/* Function Name:
 *      rtk_vlan_ipSubnetBasedVlan_set
 * Description:
 *      Set IP-Subnet-based vlan.
 * Input:
 *      unit     - unit id
 *      index    - entry index
 *      valid    - validate or invalidate the entry
 *      sip      - source IP address
 *      sip_mask - source IP address mask
 *      vid      - VLAN ID
 *      priority - assign internal priority for untag packet
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_VLAN_VID             - invalid vlan id
 *      RT_ERR_PRIORITY             - invalid priority value
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in IP-Subnet-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_ipSubnetBasedVlan_set(
    uint32      unit,
    uint32      index,
    uint32      valid,
    ipaddr_t    sip,
    ipaddr_t    sip_mask,
    rtk_vlan_t  vid,
    rtk_pri_t   priority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_ipSubnetBasedVlan_set(unit, index, valid, sip, sip_mask, vid, priority);
} /* end of rtk_vlan_ipSubnetBasedVlan_set */

/* Function Name:
 *      rtk_vlan_ipSubnetBasedVlanWithPort_get
 * Description:
 *      Get IP-Subnet-based vlan with source port ID mask.
 * Input:
 *      unit      - unit id
 *      index     - entry index
 * Output:
 *      pValid    - pointer buffer of validate or invalidate the entry
 *      pSip      - pointer buffer of source IP address
 *      pSip_mask - pointer buffer of source IP address mask
 *      pPort      - pointer buffer of source IP address
 *      pPort_mask - pointer buffer of source IP address mask
 *      pVid      - pointer buffer of VLAN ID
 *      pPriority - pointer buffer of assign internal priority for untag packet
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in IP-Subnet-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_ipSubnetBasedVlanWithPort_get(
    uint32      unit,
    uint32      index,
    uint32      *pValid,
    ipaddr_t    *pSip,
    ipaddr_t    *pSip_mask,
    rtk_port_t  *pPort,
    rtk_port_t  *pPort_mask,
    rtk_vlan_t  *pVid,
    rtk_pri_t   *pPriority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_ipSubnetBasedVlanWithPort_get(unit, index, pValid, pSip, pSip_mask, pPort, pPort_mask, pVid, pPriority);
} /* end of rtk_vlan_ipSubnetBasedVlanWithPort_get */

/* Function Name:
 *      rtk_vlan_ipSubnetBasedVlanWithPort_set
 * Description:
 *      Set IP-Subnet-based vlan with source port ID mask.
 * Input:
 *      unit     - unit id
 *      index    - entry index
 *      valid    - validate or invalidate the entry
 *      sip      - source IP address
 *      sip_mask - source IP address mask
 *      port      - source port ID
 *      port_mask - source port ID mask
 *      vid      - VLAN ID
 *      priority - assign internal priority for untag packet
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - index or port ID mask is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_VLAN_VID             - invalid vlan id
 *      RT_ERR_PRIORITY             - invalid priority value
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in IP-Subnet-based VLAN mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_ipSubnetBasedVlanWithPort_set(
    uint32      unit,
    uint32      index,
    uint32      valid,
    ipaddr_t    sip,
    ipaddr_t    sip_mask,
    rtk_port_t  port,
    rtk_port_t  port_mask,
    rtk_vlan_t  vid,
    rtk_pri_t   priority)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_ipSubnetBasedVlanWithPort_set(unit, index, valid, sip, sip_mask, port, port_mask, vid, priority);
} /* end of rtk_vlan_ipSubnetBasedVlanWithPort_set */

/* Function Name:
 *      rtk_vlan_protoGroup_get
 * Description:
 *      Get protocol group for protocol based vlan.
 * Input:
 *      unit           - unit id
 *      protoGroup_idx - protocol group index
 * Output:
 *      pProtoGroup    - pointer to protocol group
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - protocol group index is out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390
 * Note:
 *      (1) The valid range of protoGroup_idx is 0~7
 */
int32
rtk_vlan_protoGroup_get(
    uint32                  unit,
    uint32                  protoGroup_idx,
    rtk_vlan_protoGroup_t   *pProtoGroup)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_protoGroup_get(unit, protoGroup_idx, pProtoGroup);
} /* end of rtk_vlan_protoGroup_get */

/* Function Name:
 *      rtk_vlan_protoGroup_set
 * Description:
 *      Set protocol group for protocol based vlan.
 * Input:
 *      unit           - unit id
 *      protoGroup_idx - protocol group index
 *      protoGroup     - protocol group
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID         - invalid unit id
 *      RT_ERR_NOT_INIT        - The module is not initial
 *      RT_ERR_VLAN_FRAME_TYPE - invalid frame type
 *      RT_ERR_OUT_OF_RANGE    - protocol group index is out of range
 *      RT_ERR_INPUT           - invalid input parameter
 *      RT_ERR_NULL_POINTER    - input parameter may be null pointer
 * Applicable:
 *      8328, 8390
 * Note:
 *      (1) The valid range of protoGroup_idx is 0~7
 *      (2) Frame type is as following:
 *          - FRAME_TYPE_ETHERNET
 *          - FRAME_TYPE_RFC1042 (SNAP)
 *          - FRAME_TYPE_LLCOTHER
 */
int32
rtk_vlan_protoGroup_set(
    uint32                  unit,
    uint32                  protoGroup_idx,
    rtk_vlan_protoGroup_t   *pProtoGroup)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_protoGroup_set(unit, protoGroup_idx, pProtoGroup);
} /* end of rtk_vlan_protoGroup_set */

/* Function Name:
 *      rtk_vlan_portProtoVlan_get
 * Description:
 *      Get VLAN and priority configuration of specified protocol group on port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 *      protoGroup_idx - protocol group index
 * Output:
 *      pVlan_cfg      - pointer to vlan configuration of protocol group
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - protocol group index is out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390
 * Note:
 *      (1) The valid range of protoGroup_idx is 0~7
 */
int32
rtk_vlan_portProtoVlan_get(
    uint32                  unit,
    rtk_port_t              port,
    uint32                  protoGroup_idx,
    rtk_vlan_protoVlanCfg_t *pVlan_cfg)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portProtoVlan_get(unit, port, protoGroup_idx, pVlan_cfg);
} /* end of rtk_vlan_portProtoVlan_get */

/* Function Name:
 *      rtk_vlan_portProtoVlan_set
 * Description:
 *      Set VLAN and priority configuration of specified protocol group on port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 *      protoGroup_idx - protocol group index
 *      pVlan_cfg      - vlan configuration of protocol group
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID         - invalid unit id
 *      RT_ERR_NOT_INIT        - The module is not initial
 *      RT_ERR_PORT_ID         - invalid port id
 *      RT_ERR_OUT_OF_RANGE    - protocol group index is out of range
 *      RT_ERR_VLAN_VID        - invalid vlan id
 *      RT_ERR_QOS_1P_PRIORITY - Invalid 802.1p priority
 *      RT_ERR_INPUT           - invalid input parameter
 *      RT_ERR_NULL_POINTER    - input parameter may be null pointer
 * Applicable:
 *      8328, 8390
 * Note:
 *      (1) The valid range of protoGroup_idx is 0~7
 *      (2) Frame type is as following:
 *          - FRAME_TYPE_ETHERNET
 *          - FRAME_TYPE_RFC1042 (SNAP)
 *          - FRAME_TYPE_LLCOTHER
 */
int32
rtk_vlan_portProtoVlan_set(
    uint32                  unit,
    rtk_port_t              port,
    uint32                  protoGroup_idx,
    rtk_vlan_protoVlanCfg_t *pVlan_cfg)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portProtoVlan_set(unit, port, protoGroup_idx, pVlan_cfg);
} /* end of rtk_vlan_portProtoVlan_set */

/* Function Name:
 *      rtk_vlan_portOuterProtoVlan_get
 * Description:
 *      Get outer vlan of specificed protocol group on specified port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 *      protoGroup_idx - protocol group index
 * Output:
 *      pVlan_cfg      - pointer to vlan configuration of protocol group
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - protocol group index is out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      (1) The valid range of protoGroup_idx is 0~7
 */
int32
rtk_vlan_portOuterProtoVlan_get(
    uint32                  unit,
    rtk_port_t              port,
    uint32                  protoGroup_idx,
    rtk_vlan_protoVlanCfg_t *pVlan_cfg)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portOuterProtoVlan_get(unit, port, protoGroup_idx, pVlan_cfg);
} /* end of rtk_vlan_portOuterProtoVlan_get */

/* Function Name:
 *      rtk_vlan_portOuterProtoVlan_set
 * Description:
 *      Set outer vlan of specificed protocol group on specified port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 *      protoGroup_idx - protocol group index
 *      pVlan_cfg      - vlan configuration of protocol group
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - protocol group index is out of range
 *      RT_ERR_INPUT        - invalid input parameter
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      (1) The valid range of protoGroup_idx is 0~7
 *      (2) Frame type is as following:
 *          - FRAME_TYPE_ETHERNET
 *          - FRAME_TYPE_RFC1042 (SNAP)
 *          - FRAME_TYPE_LLCOTHER
 */
int32
rtk_vlan_portOuterProtoVlan_set(
    uint32                  unit,
    rtk_port_t              port,
    uint32                  protoGroup_idx,
    rtk_vlan_protoVlanCfg_t *pVlan_cfg)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portOuterProtoVlan_set(unit, port, protoGroup_idx, pVlan_cfg);
} /* end of rtk_vlan_portOuterProtoVlan_set */

/* Module Name    : Vlan               */
/* Sub-module Name: TPID configuration */

/* Function Name:
 *      rtk_vlan_innerTpidEntry_get
 * Description:
 *      Get inner TPID value from global inner TPID pool.
 * Input:
 *      unit     - unit id
 *      tpid_idx - index of TPID entry
 * Output:
 *      pTpid    - pointer to TPID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Global four inner TPID can be specified.
 */
int32
rtk_vlan_innerTpidEntry_get(uint32 unit, uint32 tpid_idx, uint32 *pTpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_innerTpidEntry_get(unit, tpid_idx, pTpid);
} /* end of rtk_vlan_innerTpidEntry_get */

/* Function Name:
 *      rtk_vlan_innerTpidEntry_set
 * Description:
 *      Set inner TPID value to global inner TPID pool.
 * Input:
 *      unit     - unit id
 *      tpid_idx - index of TPID entry
 *      tpid     - TPID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Applicable:
 *      8390, 8380
 * Note:
 *      Global four inner TPID can be specified.
 */
int32
rtk_vlan_innerTpidEntry_set(uint32 unit, uint32 tpid_idx, uint32 tpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_innerTpidEntry_set(unit, tpid_idx, tpid);
} /* end of rtk_vlan_innerTpidEntry_set */

/* Function Name:
 *      rtk_vlan_outerTpidEntry_get
 * Description:
 *      Get outer TPID value from global outer TPID pool.
 * Input:
 *      unit     - unit id
 *      tpid_idx - index of TPID entry
 * Output:
 *      pTpid    - pointer to TPID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Global four outer TPID can be specified.
 */
int32
rtk_vlan_outerTpidEntry_get(uint32 unit, uint32 tpid_idx, uint32 *pTpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_outerTpidEntry_get(unit, tpid_idx, pTpid);
} /* end of rtk_vlan_outerTpidEntry_get */

/* Function Name:
 *      rtk_vlan_outerTpidEntry_set
 * Description:
 *      Set outer TPID value to global outer TPID pool.
 * Input:
 *      unit     - unit id
 *      tpid_idx - index of TPID entry
 *      tpid     - TPID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Applicable:
 *      8390, 8380
 * Note:
 *      Global four outer TPID can be specified.
 */
int32
rtk_vlan_outerTpidEntry_set(uint32 unit, uint32 tpid_idx, uint32 tpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_outerTpidEntry_set(unit, tpid_idx, tpid);
} /* end of rtk_vlan_outerTpidEntry_set */

/* Function Name:
 *      rtk_vlan_extraTpidEntry_get
 * Description:
 *      Get the TPID value of extra tag.
 * Input:
 *      unit     - unit id
 *      tpid_idx - index of TPID entry
 * Output:
 *      pTpid    - pointer to TPID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      (1) Only one extra tag is supported. System will bypass extra tag
 *          and keeps parsing the remaining payload.
 *      (2) Following tag combination are supported for parsing an extra tag:
 *          outer+innet+extra, outer+extra, inner+extra
 */
int32
rtk_vlan_extraTpidEntry_get(uint32 unit, uint32 tpid_idx, uint32 *pTpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_extraTpidEntry_get(unit, tpid_idx, pTpid);
} /* end of rtk_vlan_extraTpidEntry_get */

/* Function Name:
 *      rtk_vlan_extraTpidEntry_set
 * Description:
 *      Set TPID value of extra tag.
 * Input:
 *      unit     - unit id
 *      tpid_idx - index of TPID entry
 *      tpid     - TPID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Applicable:
 *      8390, 8380
 * Note:
 *      (1) Only one extra tag is supported. System will bypass extra tag
 *          and keeps parsing the remaining payload.
 *      (2) Following tag combination are supported for parsing an extra tag:
 *          outer+innet+extra, outer+extra, inner+extra
 */
int32
rtk_vlan_extraTpidEntry_set(uint32 unit, uint32 tpid_idx, uint32 tpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_extraTpidEntry_set(unit, tpid_idx, tpid);
} /* end of rtk_vlan_extraTpidEntry_set */

/* Function Name:
 *      rtk_vlan_portTpidEntry_get
 * Description:
 *      Get TPID of TPID entry on specified port.
 * Input:
 *      unit     - unit id
 *      port     - port id
 *      tpid_idx - index of TPID entry
 * Output:
 *      pTpid    - pointer to TPID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      The valid range of tpid_idx is 0~3 in 8328
 */
int32
rtk_vlan_portTpidEntry_get(uint32 unit, rtk_port_t port, uint32 tpid_idx, uint32 *pTpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portTpidEntry_get(unit, port, tpid_idx, pTpid);
} /* end of rtk_vlan_portTpidEntry_get */

/* Function Name:
 *      rtk_vlan_portTpidEntry_set
 * Description:
 *      Set tpid of TPID entry on specified port.
 * Input:
 *      unit     - unit id
 *      port     - port id
 *      tpid_idx - index of TPID entry
 *      tpid     - TPID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Applicable:
 *      8328
 * Note:
 *      The valid range of tpid_idx is 0~3 in 8328
 */
int32
rtk_vlan_portTpidEntry_set(uint32 unit, rtk_port_t port, uint32 tpid_idx, uint32 tpid)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portTpidEntry_set(unit, port, tpid_idx, tpid);
} /* end of rtk_vlan_portTpidEntry_set */

/* Function Name:
 *      rtk_vlan_portEgrInnerTpidMode_get
 * Description:
 *      Get TPID mode of inner tag at egress.
 *      TPID mode will decide what kind of packet should be replaced inner TPID with configured one.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pTpid_mode - pointer to inner TPID mode at egress
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      Inner TPID mode is as following:
 *      - EGR_TPID_MODE_IGR_UNTAG_AND_EGR_TAG
 *      - EGR_TPID_MODE_ALL_PACKETS
 */
int32
rtk_vlan_portEgrInnerTpidMode_get(uint32 unit, rtk_port_t port, rtk_vlan_egrTpidMode_t *pTpid_mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerTpidMode_get(unit, port, pTpid_mode);
} /* end of rtk_vlan_portEgrInnerTpidMode_get */

/* Function Name:
 *      rtk_vlan_portEgrInnerTpidMode_set
 * Description:
 *      Set TPID mode of inner tag at egress.
 *      TPID mode will decide what kind of packet should be replaced inner TPID with configured one.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      tpid_mode - inner TPID mode at egress
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      Inner TPID mode is as following:
 *      - EGR_TPID_MODE_IGR_UNTAG_AND_EGR_TAG
 *      - EGR_TPID_MODE_ALL_PACKETS
 */
int32
rtk_vlan_portEgrInnerTpidMode_set(uint32 unit, rtk_port_t port, rtk_vlan_egrTpidMode_t tpid_mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerTpidMode_set(unit, port, tpid_mode);
} /* end of rtk_vlan_portEgrInnerTpidMode_set */

/* Function Name:
 *      rtk_vlan_portIgrInnerTpid_get
 * Description:
 *      Get inner TPIDs comparsion configration on specified port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 * Output:
 *      pTpid_idx_mask - pointer to mask for index of tpid entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Specify which TPID to compare from TPID pool for parsing a inner-tagged packet.
 *      The valid mask bits of tpid_idx is bit[3:0].
 */
int32
rtk_vlan_portIgrInnerTpid_get(uint32 unit, rtk_port_t port, uint32 *pTpid_idx_mask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrInnerTpid_get(unit, phy_port, pTpid_idx_mask);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrInnerTpid_get(unit, port, pTpid_idx_mask);
#endif
} /* end of rtk_vlan_portIgrInnerTpid_get */

/* Function Name:
 *      rtk_vlan_portIgrInnerTpid_set
 * Description:
 *      Set inner TPIDs comparsion configration on specified port
 * Input:
 *      unit          - unit id
 *      port          - port id
 *      tpid_idx_mask - mask for index of tpid entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Specify which TPID to compare from TPID pool for parsing a inner-tagged packet.
 *      The valid mask bits of tpid_idx is bit[3:0].
 */
int32
rtk_vlan_portIgrInnerTpid_set(uint32 unit, rtk_port_t port, uint32 tpid_idx_mask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrInnerTpid_set(unit, phy_port, tpid_idx_mask);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrInnerTpid_set(unit, port, tpid_idx_mask);
#endif
} /* end of rtk_vlan_portIgrInnerTpid_set */

/* Function Name:
 *      rtk_vlan_portEgrInnerTpid_get
 * Description:
 *      Get inner TPID for inner tag encapsulation when transmiiting a inner-tagged pacekt.
 * Input:
 *      unit      - unit id
 *      port      - port id
 * Output:
 *      pTpid_idx - pointer to index of inner TPID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) The valid range of tpid_idx is 0~3.
 *      (2) The inner TPID is used when transmiiting a inner-tagged pacekt only if it is received as
 *          an inner-untag pacekt.
 */
int32
rtk_vlan_portEgrInnerTpid_get(uint32 unit, rtk_port_t port, uint32 *pTpid_idx)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrInnerTpid_get(unit, phy_port, pTpid_idx);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrInnerTpid_get(unit, port, pTpid_idx);
#endif
} /* end of rtk_vlan_portEgrInnerTpid_get */

/* Function Name:
 *      rtk_vlan_portEgrInnerTpid_set
 * Description:
 *      Set inner TPID for inner tag encapsulation when transmiiting a inner-tagged pacekt.
 * Input:
 *      unit     - unit id
 *      port     - port id
 *      tpid_idx - index of inner TPID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) The valid range of tpid_idx is 0~3.
 *      (2) The inner TPID is used when transmiiting a inner-tagged pacekt only if it is received as
 *          an inner-untag pacekt.
 */
int32
rtk_vlan_portEgrInnerTpid_set(uint32 unit, rtk_port_t port, uint32 tpid_idx)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrInnerTpid_set(unit, phy_port, tpid_idx);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrInnerTpid_set(unit, port, tpid_idx);
#endif
} /* end of rtk_vlan_portEgrInnerTpid_set */

/* Function Name:
 *      rtk_vlan_portEgrOuterTpidMode_get
 * Description:
 *      Get TPID mode of outer tag at egress.
 *      TPID mode will decide what kind of packet should be replaced outer TPID with configured one.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pTpid_mode - pointer to outer TPID mode at egress
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      Inner TPID mode is as following:
 *      - EGR_TPID_MODE_IGR_UNTAG_AND_EGR_TAG
 *      - EGR_TPID_MODE_ALL_PACKETS
 */
int32
rtk_vlan_portEgrOuterTpidMode_get(uint32 unit, rtk_port_t port, rtk_vlan_egrTpidMode_t *pTpid_mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterTpidMode_get(unit, port, pTpid_mode);
} /* end of rtk_vlan_portEgrOuterTpidMode_get */

/* Function Name:
 *      rtk_vlan_portEgrOuterTpidMode_set
 * Description:
 *      Set TPID mode of outer tag at egress.
 *      TPID mode will decide what kind of packet should be replaced outer TPID with configured one.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      tpid_mode - outer TPID mode at egress
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      Inner TPID mode is as following:
 *      - EGR_TPID_MODE_IGR_UNTAG_AND_EGR_TAG
 *      - EGR_TPID_MODE_ALL_PACKETS
 */
int32
rtk_vlan_portEgrOuterTpidMode_set(uint32 unit, rtk_port_t port, rtk_vlan_egrTpidMode_t tpid_mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterTpidMode_set(unit, port, tpid_mode);
} /* end of rtk_vlan_portEgrOuterTpidMode_set */

/* Function Name:
 *      rtk_vlan_portIgrOuterTpid_get
 * Description:
 *      Get outer TPIDs comparsion configration on specified port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 * Output:
 *      pTpid_idx_mask - pointer to mask for index of tpid entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Specify which TPID to compare from TPID pool for parsing a outer-tagged packet.
 *      The valid mask bits of tpid_idx is bit[3:0].
 */
int32
rtk_vlan_portIgrOuterTpid_get(uint32 unit, rtk_port_t port, uint32 *pTpid_idx_mask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrOuterTpid_get(unit, phy_port, pTpid_idx_mask);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrOuterTpid_get(unit, port, pTpid_idx_mask);
#endif
} /* end of rtk_vlan_portIgrOuterTpid_get */

/* Function Name:
 *      rtk_vlan_portIgrOuterTpid_set
 * Description:
 *      Set outer TPIDs comparsion configration on specified port.
 * Input:
 *      unit          - unit id
 *      port          - port id
 *      tpid_idx_mask - mask for index of tpid entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Specify which TPID to compare from TPID pool for parsing a outer-tagged packet.
 *      The valid mask bits of tpid_idx is bit[3:0].
 */
int32
rtk_vlan_portIgrOuterTpid_set(uint32 unit, rtk_port_t port, uint32 tpid_idx_mask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrOuterTpid_set(unit, phy_port, tpid_idx_mask);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrOuterTpid_set(unit, port, tpid_idx_mask);
#endif
} /* end of rtk_vlan_portIgrOuterTpid_set */

/* Function Name:
 *      rtk_vlan_portEgrOuterTpid_get
 * Description:
 *      Get outer TPID for outer tag encapsulation when transmiiting a outer-tagged pacekt.
 * Input:
 *      unit      - unit id
 *      port      - port id
 * Output:
 *      pTpid_idx - pointer to index of outer TPID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) The valid range of tpid_idx is 0~3.
 *      (2) The outer TPID is used when transmiiting a outer-tagged pacekt only if it is received as
 *          an outer-untag pacekt.
 */
int32
rtk_vlan_portEgrOuterTpid_get(uint32 unit, rtk_port_t port, uint32 *pTpid_idx)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrOuterTpid_get(unit, phy_port, pTpid_idx);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrOuterTpid_get(unit, port, pTpid_idx);
#endif
} /* end of rtk_vlan_portEgrOuterTpid_get */

/* Function Name:
 *      rtk_vlan_portEgrOuterTpid_set
 * Description:
 *      Set outer TPID for outer tag encapsulation when transmiiting a outer-tagged pacekt.
 * Input:
 *      unit     - unit id
 *      port     - port id
 *      tpid_idx - index of outer TPID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) The valid range of tpid_idx is 0~3.
 *      (2) The outer TPID is used when transmiiting a outer-tagged pacekt only if it is received as
 *          an outer-untag pacekt.
 */
int32
rtk_vlan_portEgrOuterTpid_set(uint32 unit, rtk_port_t port, uint32 tpid_idx)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrOuterTpid_set(unit, phy_port, tpid_idx);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrOuterTpid_set(unit, port, tpid_idx);
#endif
} /* end of rtk_vlan_portEgrOuterTpid_set */

/* Function Name:
 *      rtk_vlan_portIgrExtraTpid_get
 * Description:
 *      Get extra TPIDs comparsion configration on specified port.
 * Input:
 *      unit           - unit id
 *      port           - port id
 * Output:
 *      pTpid_idx_mask - pointer to mask for index of tpid entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      The valid mask bits of tpid_idx is bit[3:0].
 */
int32
rtk_vlan_portIgrExtraTpid_get(uint32 unit, rtk_port_t port, uint32 *pTpid_idx_mask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrExtraTpid_get(unit, port, pTpid_idx_mask);
} /* end of rtk_vlan_portIgrExtraTpid_get */

/* Function Name:
 *      rtk_vlan_portIgrExtraTpid_set
 * Description:
 *      Set extra TPIDs comparsion configration on specified port.
 * Input:
 *      unit          - unit id
 *      port          - port id
 *      tpid_idx_mask - mask for index of tpid entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      The valid mask bits of tpid_idx is bit[3:0].
 */
int32
rtk_vlan_portIgrExtraTpid_set(uint32 unit, rtk_port_t port, uint32 tpid_idx_mask)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrExtraTpid_set(unit, port, tpid_idx_mask);
} /* end of rtk_vlan_portIgrExtraTpid_set */

/* Module Name    : Vlan                 */
/* Sub-module Name: Ingress tag handling */

/* Function Name:
 *      rtk_vlan_portIgrIgnoreInnerTagEnable_get
 * Description:
 *      Get enable status of ignore inner tag at ingress.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - enable status of ignore inner tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      None
 */
int32
rtk_vlan_portIgrIgnoreInnerTagEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrIgnoreInnerTagEnable_get(unit, port, pEnable);
} /* end of rtk_vlan_portIgrIgnoreInnerTagEnable_get */

/* Function Name:
 *      rtk_vlan_portIgrIgnoreInnerTagEnable_set
 * Description:
 *      Set enable status of ignore inner tag at ingress.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of ignore inner tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      None
 */
int32
rtk_vlan_portIgrIgnoreInnerTagEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrIgnoreInnerTagEnable_set(unit, port, enable);
} /* end of rtk_vlan_portIgrIgnoreInnerTagEnable_set */

/* Function Name:
 *      rtk_vlan_portIgrIgnoreOuterTagEnable_get
 * Description:
 *      Get enable status of ignore outer tag at ingress.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status of ignore outer tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      None
 */
int32
rtk_vlan_portIgrIgnoreOuterTagEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrIgnoreOuterTagEnable_get(unit, port, pEnable);
} /* end of rtk_vlan_portIgrIgnoreOuterTagEnable_get */

/* Function Name:
 *      rtk_vlan_portIgrIgnoreOuterTagEnable_set
 * Description:
 *      Set enable status of ignore outer tag at ingress.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of ignore outer tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      None
 */
int32
rtk_vlan_portIgrIgnoreOuterTagEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrIgnoreOuterTagEnable_set(unit, port, enable);
} /* end of rtk_vlan_portIgrIgnoreOuterTagEnable_set */

/* Module Name    : Vlan                */
/* Sub-module Name: Egress tag handling */

/* Function Name:
 *      rtk_vlan_portEgrInnerTagEnable_get
 * Description:
 *      Get enable status of inner tag capability at egress.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status of inner tag capability
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) Egress packet will send out with inner tag when following is true.
 *          - inner tag capability is enable
 *          - this port is tag member of specified vlan
 *      (2) For 8390 and 8380, the function is backward compatible RTL8328 APIs. 
 */
int32
rtk_vlan_portEgrInnerTagEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerTagEnable_get(unit, port, pEnable);
} /* end of rtk_vlan_portEgrInnerTagEnable_get */

/* Function Name:
 *      rtk_vlan_portEgrInnerTagEnable_set
 * Description:
 *      Set enable status of inner tag capability at egress.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of inner tag capability
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) Egress packet will send out with inner tag when following is true.
 *          - inner tag capability is enable
 *          - this port is tag member of specified vlan
 *      (2) For 8390 and 8380, the function is backward compatible RTL8328 APIs. 
 */
int32
rtk_vlan_portEgrInnerTagEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerTagEnable_set(unit, port, enable);
} /* end of rtk_vlan_portEgrInnerTagEnable_set */

/* Function Name:
 *      rtk_vlan_portEgrOuterTagEnable_get
 * Description:
 *      Get enable status of outer tag capability at egress.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status of outer tag capability
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) Egress packet will send out with outer tag when following is true.
 *          - outer tag capability is enable
 *          - this port is tag member of specified vlan
 *      (2) For 8390 and 8380, the function is backward compatible RTL8328 APIs. 
 */
int32
rtk_vlan_portEgrOuterTagEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterTagEnable_get(unit, port, pEnable);
} /* end of rtk_vlan_portEgrOuterTagEnable_get */

/* Function Name:
 *      rtk_vlan_portEgrOuterTagEnable_set
 * Description:
 *      Set enable status of outer tag capability at egress.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of outer tag capability
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      (1) Egress packet will send out with outer tag when following is true.
 *          - outer tag capability is enable
 *          - this port is tag member of specified vlan
 *      (2) For 8390 and 8380, the function is backward compatible RTL8328 APIs. 
 */
int32
rtk_vlan_portEgrOuterTagEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterTagEnable_set(unit, port, enable);
} /* end of rtk_vlan_portEgrOuterTagEnable_set */

/* Function Name:
 *      rtk_vlan_portIgrExtraTagEnable_get
 * Description:
 *      Get enable status of recognizing extra tag at ingress.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status of recognizing extra tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portIgrExtraTagEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrExtraTagEnable_get(unit, phy_port, pEnable);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrExtraTagEnable_get(unit, port, pEnable);
#endif
} /* end of rtk_vlan_portIgrExtraTagEnable_get */

/* Function Name:
 *      rtk_vlan_portIgrExtraTagEnable_set
 * Description:
 *      Set enable status of recognizing extra tag at ingress.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of recognizing extra tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_portIgrExtraTagEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrExtraTagEnable_set(unit, phy_port, enable);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrExtraTagEnable_set(unit, port, enable);
#endif
} /* end of rtk_vlan_portIgrExtraTagEnable_set */

/* Function Name:
 *      rtk_vlan_portEgrExtraTagEnable_get
 * Description:
 *      Get enable status of recognizing extra tag at egress.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status of recognizing extra tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrExtraTagEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrExtraTagEnable_get(unit, port, pEnable);
} /* end of rtk_vlan_portEgrExtraTagEnable_get */

/* Function Name:
 *      rtk_vlan_portEgrExtraTagEnable_set
 * Description:
 *      Set enable status of recognizing extra tag at egress.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status of recognizing extra tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrExtraTagEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrExtraTagEnable_set(unit, port, enable);
} /* end of rtk_vlan_portEgrExtraTagEnable_set */

/* Function Name:
 *      rtk_vlan_portEgrInnerTagSts_get
 * Description:
 *      Set inner tag status of egress port.
 * Input:
 *      unit - unit id
 *      port - port id
 * Output:
 *      pSts - tag status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Egress packet will send out with inner tag when following is true.
 *      - inner tag status is specified to be tagged
 *      - this port is not in VLAN untag set
 */
int32
rtk_vlan_portEgrInnerTagSts_get(uint32 unit, rtk_port_t port, rtk_vlan_tagSts_t *pSts)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrInnerTagSts_get(unit, phy_port, pSts);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrInnerTagSts_get(unit, port, pSts);
#endif
} /* end of rtk_vlan_portEgrInnerTagSts_get */

/* Function Name:
 *      rtk_vlan_portEgrInnerTagSts_set
 * Description:
 *      Set inner tag status of egress port.
 * Input:
 *      unit - unit id
 *      port - port id
 *      sts  - tag status
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Egress packet will send out with inner tag when following is true.
 *      - inner tag status is specified to be tagged
 *      - this port is not in VLAN untag set
 */
int32
rtk_vlan_portEgrInnerTagSts_set(uint32 unit, rtk_port_t port, rtk_vlan_tagSts_t sts)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrInnerTagSts_set(unit, phy_port, sts);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrInnerTagSts_set(unit, port, sts);
#endif
} /* end of rtk_vlan_portEgrInnerTagSts_set */

/* Function Name:
 *      rtk_vlan_portEgrOuterTagSts_get
 * Description:
 *      Set inner tag status of egress port.
 * Input:
 *      unit - unit id
 *      port - port id
 * Output:
 *      pSts - tag status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Egress packet will send out with outer tag when following is true.
 *      - outer tag status is specified to be tagged
 *      - this port is not in VLAN untag set
 */
int32
rtk_vlan_portEgrOuterTagSts_get(uint32 unit, rtk_port_t port, rtk_vlan_tagSts_t *pSts)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrOuterTagSts_get(unit, phy_port, pSts);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrOuterTagSts_get(unit, port, pSts);
#endif
} /* end of rtk_vlan_portEgrOuterTagSts_get */

/* Function Name:
 *      rtk_vlan_portEgrOuterTagSts_set
 * Description:
 *      Set inner tag status of egress port.
 * Input:
 *      unit - unit id
 *      port - port id
 *      sts  - tag status
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Egress packet will send out with outer tag when following is true.
 *      - outer tag status is specified to be tagged
 *      - this port is not in VLAN untag set
 */
int32
rtk_vlan_portEgrOuterTagSts_set(uint32 unit, rtk_port_t port, rtk_vlan_tagSts_t sts)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrOuterTagSts_set(unit, phy_port, sts);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrOuterTagSts_set(unit, port, sts);
#endif
} /* end of rtk_vlan_portEgrOuterTagSts_set */

/* Function Name:
 *      rtk_vlan_portEgrInnerVidSource_get
 * Description:
 *      Get source of vid field in inner tag.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pVidSource - pointer to source of vid field in inner tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ALE
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 */
int32
rtk_vlan_portEgrInnerVidSource_get(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t *pVidSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerVidSource_get(unit, port, pVidSource);
} /* end of rtk_vlan_portEgrInnerVidSource_get */

/* Function Name:
 *      rtk_vlan_portEgrInnerVidSource_set
 * Description:
 *      Set source of vid field in inner tag.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      vidSource - source of vid field in inner tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ALE
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 */
int32
rtk_vlan_portEgrInnerVidSource_set(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t vidSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerVidSource_set(unit, port, vidSource);
} /* end of rtk_vlan_portEgrInnerVidSource_set */

/* Function Name:
 *      rtk_vlan_portEgrInnerPriSource_get
 * Description:
 *      Get source of priority field in inner tag.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pPriSource - pointer to source of priority field in inner tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 *      - TAG_SOURCE_NULL
 */
int32
rtk_vlan_portEgrInnerPriSource_get(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t *pPriSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerPriSource_get(unit, port, pPriSource);
} /* end of rtk_vlan_portEgrInnerPriSource_get */

/* Function Name:
 *      rtk_vlan_portEgrInnerPriSource_set
 * Description:
 *      Set source of priority field in inner tag.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      priSource - source of priority field in inner tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 *      - TAG_SOURCE_NULL
 */
int32
rtk_vlan_portEgrInnerPriSource_set(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t priSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrInnerPriSource_set(unit, port, priSource);
} /* end of rtk_vlan_portEgrInnerPriSource_set */

/* Function Name:
 *      rtk_vlan_portEgrOuterVidSource_get
 * Description:
 *      Get source of vid field in outer tag.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pVidSource - pointer to source of vid field in outer tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ALE
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 */
int32
rtk_vlan_portEgrOuterVidSource_get(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t *pVidSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterVidSource_get(unit, port, pVidSource);
} /* end of rtk_vlan_portEgrOuterVidSource_get */

/* Function Name:
 *      rtk_vlan_portEgrOuterVidSource_set
 * Description:
 *      Set source of vid field in outer tag.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      vidSource - source of vid field in outer tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ALE
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 */
int32
rtk_vlan_portEgrOuterVidSource_set(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t vidSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterVidSource_set(unit, port, vidSource);
} /* end of rtk_vlan_portEgrOuterVidSource_set */

/* Function Name:
 *      rtk_vlan_portEgrOuterPriSource_get
 * Description:
 *      Get source of priority field in outer tag.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pPriSource - pointer to source of priority field in outer tag
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 *      - TAG_SOURCE_NULL
 */
int32
rtk_vlan_portEgrOuterPriSource_get(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t *pPriSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterPriSource_get(unit, port, pPriSource);
} /* end of rtk_vlan_portEgrOuterPriSource_get */

/* Function Name:
 *      rtk_vlan_portEgrOuterPriSource_set
 * Description:
 *      Set source of priority field in outer tag.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      priSource - source of priority field in outer tag
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      Vid source is as following
 *      - TAG_SOURCE_FROM_ORIG_INNER_TAG
 *      - TAG_SOURCE_FROM_ORIG_OUTER_TAG
 *      - TAG_SOURCE_NULL
 */
int32
rtk_vlan_portEgrOuterPriSource_set(uint32 unit, rtk_port_t port, rtk_vlan_tagSource_t priSource)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portEgrOuterPriSource_set(unit, port, priSource);
} /* end of rtk_vlan_portEgrOuterPriSource_set */

/* Module Name    : Vlan                */
/* Sub-module Name: Tag format handling */

/* Function Name:
 *      rtk_vlan_tagMode_get
 * Description:
 *      Get vlan tagged mode of the port from the specified device.
 * Input:
 *      unit      - unit id
 *      port      - port id
 * Output:
 *      pTag_mode - pointer buffer of vlan tagged mode
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8389
 * Note:
 *      The vlan tagged mode as following:
 *      - VLAN_TAG_MODE_ORIGINAL        (depend on chip normal decision)
 *      - VLAN_TAG_MODE_KEEP_FORMAT     (keep ingress format to egress)
 *      - VLAN_TAG_MODE_PRI             (always priority tag out)
 */
int32
rtk_vlan_tagMode_get(uint32 unit, rtk_port_t port, rtk_vlan_tagMode_t *pTag_mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_tagMode_get(unit, port, pTag_mode);
} /* end of rtk_vlan_tagMode_get */

/* Function Name:
 *      rtk_vlan_tagMode_set
 * Description:
 *      Set vlan tagged mode of the port to the specified device.
 * Input:
 *      unit     - unit id
 *      port     - port id
 *      tag_mode - vlan tagged mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8389
 * Note:
 *      The vlan tagged mode as following:
 *      - VLAN_TAG_MODE_ORIGINAL        (depend on chip normal decision)
 *      - VLAN_TAG_MODE_KEEP_FORMAT     (keep ingress format to egress)
 *      - VLAN_TAG_MODE_PRI             (always priority tag out)
 */
int32
rtk_vlan_tagMode_set(uint32 unit, rtk_port_t port, rtk_vlan_tagMode_t tag_mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_tagMode_set(unit, port, tag_mode);
} /* end of rtk_vlan_tagMode_set */

/* Function Name:
 *      rtk_vlan_portIgrTagKeepEnable_get
 * Description:
 *      Get enable status of keep tag format at ingress.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pKeepOuter - enable status of keep outer tag format
 *      pKeepInner - enable status of keep inner tag format
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointers
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Enable keep tag format at ingress
 *      - Enable keep tag format at egress
 */
int32
rtk_vlan_portIgrTagKeepEnable_get(
    uint32          unit,
    rtk_port_t      port,
    rtk_enable_t    *pKeepOuter,
    rtk_enable_t    *pKeepInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrTagKeepEnable_get(unit, phy_port, pKeepOuter, pKeepInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrTagKeepEnable_get(unit, port, pKeepOuter, pKeepInner);
#endif
} /* end of rtk_vlan_portIgrTagKeepEnable_get */

/* Function Name:
 *      rtk_vlan_portIgrTagKeepEnable_set
 * Description:
 *      Set enable status of keep tag format at ingress.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      keepOuter - enable status of keep outer tag format
 *      keepInner - enable status of keep inner tag format
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Enable keep tag format at ingress
 *      - Enable keep tag format at egress
 */
int32
rtk_vlan_portIgrTagKeepEnable_set(
    uint32          unit,
    rtk_port_t      port,
    rtk_enable_t    keepOuter,
    rtk_enable_t    keepInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrTagKeepEnable_set(unit, phy_port, keepOuter, keepInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrTagKeepEnable_set(unit, port, keepOuter, keepInner);
#endif
} /* end of rtk_vlan_portIgrTagKeepEnable_set */

/* Function Name:
 *      rtk_vlan_portEgrTagKeepEnable_get
 * Description:
 *      Get enable status of keep tag format at egress.
 * Input:
 *      unit       - unit id
 *      port       - port id
 * Output:
 *      pKeepOuter - pointer to enable status of keep outer tag format
 *      pKeepInner - pointer to enable status of keep inner tag format
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Enable keep tag format at ingress
 *      - Enable keep tag format at egress
 */
int32
rtk_vlan_portEgrTagKeepEnable_get(
    uint32          unit,
    rtk_port_t      port,
    rtk_enable_t    *pKeepOuter,
    rtk_enable_t    *pKeepInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrTagKeepEnable_get(unit, phy_port, pKeepOuter, pKeepInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrTagKeepEnable_get(unit, port, pKeepOuter, pKeepInner);
#endif
} /* end of rtk_vlan_portEgrTagKeepEnable_get */

/* Function Name:
 *      rtk_vlan_portEgrTagKeepEnable_set
 * Description:
 *      Set enable status of keep tag format at egress.
 * Input:
 *      unit      - unit id
 *      port      - port id
 *      keepOuter - enable status of keep outer tag format
 *      keepInner - enable status of keep inner tag format
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328, 8390, 8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Enable keep tag format at ingress
 *      - Enable keep tag format at egress
 */
int32
rtk_vlan_portEgrTagKeepEnable_set(
    uint32          unit,
    rtk_port_t      port,
    rtk_enable_t    keepOuter,
    rtk_enable_t    keepInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrTagKeepEnable_set(unit, phy_port, keepOuter, keepInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrTagKeepEnable_set(unit, port, keepOuter, keepInner);
#endif
} /* end of rtk_vlan_portEgrTagKeepEnable_set */

/*
 * MISC
 */

/* Function Name:
 *      rtk_vlan_fwdMode_get
 * Description:
 *      Get packet forwarding mode on specified vlan.
 *      Packet can be forwarded by ALE decision or forward to members of vlan.
 * Input:
 *      unit  - unit id
 *      vid   - vlan id
 * Output:
 *      pMode - pointer to packet forwarding mode
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_VLAN_VID     - invalid vlan id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8328
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) Packet forwarding mode is as following:
 *          - VLAN_FWD_ON_ALE
 *          - VLAN_FWD_ON_VLAN_MEMBER
 */
int32
rtk_vlan_fwdMode_get(uint32 unit, rtk_vlan_t vid, rtk_vlan_fwdMode_t *pMode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_fwdMode_get(unit, vid, pMode);
} /* end of rtk_vlan_fwdMode_get */

/* Function Name:
 *      rtk_vlan_fwdMode_set
 * Description:
 *      Set packet forwarding mode on specified vlan.
 *      Packet can be forwarded by ALE decision or forward to members of vlan.
 * Input:
 *      unit - unit id
 *      vid  - vlan id
 *      mode - packet forwarding mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_VLAN_VID - invalid vlan id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8328
 * Note:
 *      (1) The valid range of vid is 0~4095
 *      (2) Packet forwarding mode is as following:
 *          - VLAN_FWD_ON_ALE
 *          - VLAN_FWD_ON_VLAN_MEMBER
 */
int32
rtk_vlan_fwdMode_set(uint32 unit, rtk_vlan_t vid, rtk_vlan_fwdMode_t mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_fwdMode_set(unit, vid, mode);
} /* end of rtk_vlan_fwdMode_set */

/* Function Name:
 *      rtk_vlan_igrVlanCnvtBlkMode_get
 * Description:
 *      Get the operation mode of ingress VLAN conversion table block.
 * Input:
 *      unit    - unit id
 *      blk_idx - block index
 * Output:
 *      pMode   - operation mode of ingress VLAN conversion block
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - block index is out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Valid block index ranges from 0 to 3.
 *      (2) Ingress VLAN conversion table block can be used for doing ingress VLAN conversion
 *         or MAC-basd VLAN or IP-Subnet-based VLAN.
 */
int32
rtk_vlan_igrVlanCnvtBlkMode_get(uint32 unit, uint32 blk_idx, rtk_vlan_igrVlanCnvtBlk_mode_t *pMode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrVlanCnvtBlkMode_get(unit, blk_idx, pMode);
} /* end of rtk_vlan_igrVlanCnvtBlkMode_get */

/* Function Name:
 *      rtk_vlan_igrVlanCnvtBlkMode_set
 * Description:
 *      Set the operation mode of ingress VLAN conversion table block.
 * Input:
 *      unit    - unit id
 *      blk_idx - block index
 *      mode    - operation mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - block index is out of range
 *      RT_ERR_INPUT        - invalid input parameter
 * Applicable:
 *      8390
 * Note:
 *      (1) Valid block index ranges from 0 to 3 and each block contains 256 entries.
 *      (2) Ingress VLAN conversion table block can be used for doing ingress VLAN conversion
 *         or MAC-basd VLAN or IP-Subnet-based VLAN.
 */
int32
rtk_vlan_igrVlanCnvtBlkMode_set(uint32 unit, uint32 blk_idx, rtk_vlan_igrVlanCnvtBlk_mode_t mode)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrVlanCnvtBlkMode_set(unit, blk_idx, mode);
} /* end of rtk_vlan_igrVlanCnvtBlkMode_set */

/* Function Name:
 *      rtk_vlan_igrVlanCnvtEntry_get
 * Description:
 *      Get ingress VLAN conversion entry.
 * Input:
 *      unit  - unit id
 *      index - entry index
 * Output:
 *      pData - configuration of ingress VLAN conversion entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - entry index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in ingress VLAN conversion mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_igrVlanCnvtEntry_get(uint32 unit, uint32 index, rtk_vlan_igrVlanCnvtEntry_t *pData)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrVlanCnvtEntry_get(unit, index, pData);
} /* end of rtk_vlan_igrVlanCnvtEntry_get */

/* Function Name:
 *      rtk_vlan_igrVlanCnvtEntry_set
 * Description:
 *      Set ingress VLAN conversion entry.
 * Input:
 *      unit  - unit id
 *      index - entry index
 * Output:
 *      pData - configuration of ingress VLAN conversion entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - entry index is out of range
 *      RT_ERR_VLAN_C2SC_BLOCK_MODE - try to set/get a entry to an incompatiable block
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_PORT_ID              - invalid port id
 *      RT_ERR_QOS_1P_PRIORITY      - Invalid 802.1p priority
 *      RT_ERR_VLAN_TPID_INDEX      - Invalid TPID index
 *      RT_ERR_INPUT                - invalid input parameter
 * Applicable:
 *      8390
 * Note:
 *      (1) Totally 1024 entries are supported but the entries are shared by ingress VLAN
 *          conversion, MAC-based VLAN and IP-Subnet-based VLAN functions per-block based.
 *      (2) The corresponding block must be in ingress VLAN conversion mode before calling this function,
 *          refer to rtk_vlan_igrVlanCnvtBlkMode_set.
 */
int32
rtk_vlan_igrVlanCnvtEntry_set(uint32 unit, uint32 index, rtk_vlan_igrVlanCnvtEntry_t *pData)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrVlanCnvtEntry_set(unit, index, pData);
} /* end of rtk_vlan_igrVlanCnvtEntry_set */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtDblTagEnable_get
 * Description:
 *      Enable egress VLAN conversion for dobule(outer+inner) tagged packet.
 * Input:
 *      unit    - unit id
 * Output:
 *      pEnable - pointer to enable status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      (1) Enable egress VLAN conversion for dobule tagged packet.
 *      (2) If the function is disabled, egress VLAN conversion only applies to single tagged packet.
 */
int32
rtk_vlan_egrVlanCnvtDblTagEnable_get(uint32 unit, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtDblTagEnable_get(unit, pEnable);
} /* end of rtk_vlan_egrVlanCnvtDblTagEnable_get */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtDblTagEnable_set
 * Description:
 *      Enable egress VLAN conversion for dobule(outer+inner) tagged packet.
 * Input:
 *      unit   - unit id
 *      enable - enable status
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      (1) Enable egress VLAN conversion for dobule tagged packet.
 *      (2) If the function is disabled, egress VLAN conversion only applies to single tagged packet.
 */
int32
rtk_vlan_egrVlanCnvtDblTagEnable_set(uint32 unit, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtDblTagEnable_set(unit, enable);
} /* end of rtk_vlan_egrVlanCnvtDblTagEnable_set */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtVidSource_get
 * Description:
 *      Specify the VID source for doing egress VLAN conversion.
 * Input:
 *      unit - unit id
 * Output:
 *      pSrc - pointer to VID source
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) VID source can be either from inner tag or outer tag.
 *      (2) The selected VID will be used as comparing key for doing egress VLAN conversion.
 */
int32
rtk_vlan_egrVlanCnvtVidSource_get(uint32 unit, rtk_l2_vlanMode_t *pSrc)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtVidSource_get(unit, pSrc);
} /* end of rtk_vlan_egrVlanCnvtVidSource_get */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtVidSource_set
 * Description:
 *      Specify the VID source for doing egress VLAN conversion.
 * Input:
 *      unit - unit id
 *      src  - VID source
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390
 * Note:
 *      (1) VID source can be either from inner tag or outer tag.
 *      (2) The selected VID will be used as comparing key for doing egress VLAN conversion.
 */
int32
rtk_vlan_egrVlanCnvtVidSource_set(uint32 unit, rtk_l2_vlanMode_t src)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtVidSource_set(unit, src);
} /* end of rtk_vlan_egrVlanCnvtVidSource_set */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtEntry_get
 * Description:
 *      Set egress VLAN conversion entry.
 * Input:
 *      unit  - unit id
 *      index - entry index
 * Output:
 *      pData - configuration of egress VLAN conversion entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_OUT_OF_RANGE - entry index is out of range
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      Totally 1024 entries are supported.
 */
int32
rtk_vlan_egrVlanCnvtEntry_get(uint32 unit, uint32 index, rtk_vlan_egrVlanCnvtEntry_t *pData)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32   ret;
    rtk_vlan_egrVlanCnvtEntry_t  temp_data;

    if ((ret = RT_MAPPER(unit)->vlan_egrVlanCnvtEntry_get(unit, index, &temp_data)) != RT_ERR_OK)
        return ret;
    *pData = temp_data;
    (*pData).port = PHYSICAL_PORT_TO_RTK_PORT(unit, temp_data.port);
    return ret;
    }
#else
    return RT_MAPPER(unit)->vlan_egrVlanCnvtEntry_get(unit, index, pData);
#endif
} /* end of rtk_vlan_egrVlanCnvtEntry_get */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtEntry_set
 * Description:
 *      Set egress VLAN conversion entry.
 * Input:
 *      unit  - unit id
 *      index - entry index
 * Output:
 *      pData - configuration of egress VLAN conversion entry
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID              - invalid unit id
 *      RT_ERR_NOT_INIT             - The module is not initial
 *      RT_ERR_OUT_OF_RANGE         - entry index is out of range
 *      RT_ERR_NULL_POINTER         - input parameter may be null pointer
 *      RT_ERR_VLAN_VID             - invalid vid
 *      RT_ERR_PORT_ID              - invalid port id
 *      RT_ERR_QOS_1P_PRIORITY      - Invalid 802.1p priority
 *      RT_ERR_VLAN_TPID_INDEX      - Invalid TPID index
 *      RT_ERR_INPUT                - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      Totally 1024 entries are supported.
 */
int32
rtk_vlan_egrVlanCnvtEntry_set(uint32 unit, uint32 index, rtk_vlan_egrVlanCnvtEntry_t *pData)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    rtk_vlan_egrVlanCnvtEntry_t  temp_data;

    temp_data = *pData;
    temp_data.port = RTK_PORT_TO_PHYSICAL_PORT(unit, (*pData).port);
    return RT_MAPPER(unit)->vlan_egrVlanCnvtEntry_set(unit, index, &temp_data);
    }
#else
    return RT_MAPPER(unit)->vlan_egrVlanCnvtEntry_set(unit, index, pData);
#endif
} /* end of rtk_vlan_egrVlanCnvtEntry_set */

/* Function Name:
 *      rtk_vlan_portVlanAggrEnable_get
 * Description:
 *      Enable N:1 VLAN aggregation support on egress port.
 * Input:
 *      unit    - unit id
 *      port    - port id
 * Output:
 *      pEnable - pointer to enable status
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      (1) When the N:1 VLAN aggregation function is enabled on a egress port, the inner VID
 *          of the downstream packet will be replaced by the VID which learnt in L2 table from
 *          upstream packet.
 *      (2) N:1 VLAN replacement only applies to the inner tagged and known unicast packet.
 */
int32
rtk_vlan_portVlanAggrEnable_get(uint32 unit, rtk_port_t port, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portVlanAggrEnable_get(unit, phy_port, pEnable);
    }
#else
    return RT_MAPPER(unit)->vlan_portVlanAggrEnable_get(unit, port, pEnable);
#endif
} /* end of rtk_vlan_portVlanAggrEnable_get */

/* Function Name:
 *      rtk_vlan_portVlanAggrEnable_set
 * Description:
 *      Enable N:1 VLAN aggregation support on egress port.
 * Input:
 *      unit   - unit id
 *      port   - port id
 *      enable - enable status
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      (1) When the N:1 VLAN aggregation function is enabled on a egress port, the inner VID
 *          of the downstream packet will be replaced by the VID which learnt in L2 table from
 *          upstream packet.
 *      (2) N:1 VLAN replacement only applies to the inner tagged and known unicast packet.
 */
int32
rtk_vlan_portVlanAggrEnable_set(uint32 unit, rtk_port_t port, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || RT_MGMT(unit) == NULL, RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portVlanAggrEnable_set(unit, phy_port, enable);
    }
#else
    return RT_MAPPER(unit)->vlan_portVlanAggrEnable_set(unit, port, enable);
#endif
} /* end of rtk_vlan_portVlanAggrEnable_set */

/* Function Name:
 *      rtk_vlan_leakyStpFilter_get
 * Description:
 *      Get leaky STP filter status for multicast leaky is enabled.
 * Input:
 *      unit    - unit id
 * Output:
 *      pEnable - pointer to status of leaky STP filter
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_leakyStpFilter_get(uint32 unit, rtk_enable_t *pEnable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_leakyStpFilter_get(unit, pEnable);
} /* end of rtk_vlan_leakyStpFilter_get */

/* Function Name:
 *      rtk_vlan_leakyStpFilter_set
 * Description:
 *      Set leaky STP filter status for multicast leaky is enabled.
 * Input:
 *      unit   - unit id
 *      enable - status of leaky STP filter
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_leakyStpFilter_set(uint32 unit, rtk_enable_t enable)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_leakyStpFilter_set(unit, enable);
} /* end of rtk_vlan_leakyStpFilter_set */

/* Function Name:
 *      rtk_vlan_except_get
 * Description:
 *      Get VLAN except action.
 * Input:
 *      unit    - unit id
 * Output:
 *      pAction - pointer to action of VLAN except
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      (1) VLAN exception is asserted if
 *          received packet with VID=4095 or its VLAN member=0.
 *      (2) Forwarding action is as following
 *          - ACTION_DROP
 *          - ACTION_FORWARD
 *          - ACTION_TRAP2CPU
 */
int32
rtk_vlan_except_get(uint32 unit, rtk_action_t *pAction)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_except_get(unit, pAction);
} /* end of rtk_vlan_except_get */

/* Function Name:
 *      rtk_vlan_except_set
 * Description:
 *      Set VLAN except action.
 * Input:
 *      unit   - unit id
 *      action - action of VLAN except
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390
 * Note:
 *      (1) VLAN exception is asserted if
 *          received packet with VID=4095 or its VLAN member=0.
 *      (2) Forwarding action is as following
 *          - ACTION_DROP
 *          - ACTION_FORWARD
 *          - ACTION_TRAP2CPU
 */
int32
rtk_vlan_except_set(uint32 unit, rtk_action_t action)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_except_set(unit, action);
} /* end of rtk_vlan_except_set */

/* Function Name:
 *      rtk_vlan_portIgrCnvtDfltAct_get
 * Description:
 *      Get action for packet that doesn't hit ingress ACL and C2SC.
 * Input:
 *      unit    - unit id
 *      port    - port id for configure
 * Output:
 *      pAction - pointer to VLAN conversion default action
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390
 * Note:
 *      Forwarding action is as following
 *      - ACTION_DROP
 *      - ACTION_FORWARD
 */
int32
rtk_vlan_portIgrCnvtDfltAct_get(uint32 unit, rtk_port_t port, rtk_action_t *pAction)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrCnvtDfltAct_get(unit, port, pAction);
} /* end of rtk_vlan_portIgrCnvtDfltAct_get */

/* Function Name:
 *      rtk_vlan_portIgrCnvtDfltAct_set
 * Description:
 *      Set action for packet that doesn't hit ingress ACL and C2SC.
 * Input:
 *      unit   - unit id
 *      port   - port id for configure
 *      action - VLAN conversion default action
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8390
 * Note:
 *      Forwarding action is as following
 *      - ACTION_DROP
 *      - ACTION_FORWARD
 */
int32
rtk_vlan_portIgrCnvtDfltAct_set(uint32 unit, rtk_port_t port, rtk_action_t action)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_portIgrCnvtDfltAct_set(unit, port, action);
} /* end of rtk_vlan_portIgrCnvtDfltAct_set */

/* Function Name:
 *      rtk_vlan_portIgrTagKeepType_get
 * Description:
 *      Get keep type of keep tag format at igress.
 * Input:
 *      unit           - unit id
 *      port           - port id
 * Output:
 *      pKeeptypeOuter - pointer to enable status of keep outer tag format
 *      pKeeptypeInner - pointer to enable status of keep inner tag format
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
  * Applicable:
 *      8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Enable keep tag format at ingress
 *      - Enable keep tag format at egress
 */
int32
rtk_vlan_portIgrTagKeepType_get(
    uint32                  unit,
    rtk_port_t              port,
    rtk_vlan_tagKeepType_t  *pKeeptypeOuter,
    rtk_vlan_tagKeepType_t  *pKeeptypeInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrTagKeepType_get(unit, phy_port, pKeeptypeOuter, pKeeptypeInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrTagKeepType_get(unit, port, pKeeptypeOuter, pKeeptypeInner);
#endif
} /* end of rtk_vlan_portIgrTagKeepType_get */

/* Function Name:
 *      rtk_vlan_portIgrTagKeepType_set
 * Description:
 *      Set keep type of keep tag format at igress.
 * Input:
 *      unit          - unit id
 *      port          - port id
 *      keeptypeOuter - keep type of keep outer tag format
 *      keeptypeInner - keep type of keep inner tag format
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Set keep type of keep tag format at ingress
 *      - Set keep type of keep tag format at egress
 */
int32
rtk_vlan_portIgrTagKeepType_set(
    uint32                  unit,
    rtk_port_t              port,
    rtk_vlan_tagKeepType_t  keeptypeOuter,
    rtk_vlan_tagKeepType_t  keeptypeInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portIgrTagKeepType_set(unit, phy_port, keeptypeOuter, keeptypeInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portIgrTagKeepType_set(unit, port, keeptypeOuter, keeptypeInner);
#endif
} /* end of rtk_vlan_portIgrTagKeepType_set */

/* Function Name:
 *      rtk_vlan_portEgrTagKeepType_get
 * Description:
 *      Get keep type of keep tag format at egress.
 * Input:
 *      unit           - unit id
 *      port           - port id
 * Output:
 *      pKeeptypeOuter - pointer to enable status of keep outer tag format
 *      pKeeptypeInner - pointer to enable status of keep inner tag format
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Enable keep tag format at ingress
 *      - Enable keep tag format at egress
 */
int32
rtk_vlan_portEgrTagKeepType_get(
    uint32                  unit,
    rtk_port_t              port,
    rtk_vlan_tagKeepType_t  *pKeeptypeOuter,
    rtk_vlan_tagKeepType_t  *pKeeptypeInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrTagKeepType_get(unit, phy_port, pKeeptypeOuter, pKeeptypeInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrTagKeepType_get(unit, port, pKeeptypeOuter, pKeeptypeInner);
#endif
} /* end of rtk_vlan_portEgrTagKeepType_get */

/* Function Name:
 *      rtk_vlan_portEgrTagKeepType_set
 * Description:
 *      Set keep type of keep tag format at egress.
 * Input:
 *      unit          - unit id
 *      port          - port id
 *      keeptypeOuter - keep type of keep outer tag format
 *      keeptypeInner - keep type of keep inner tag format
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      Packet will be transmitted with original tag format when following condition are true.
 *      - Set keep type of keep tag format at ingress
 *      - Set keep type of keep tag format at egress
 */
int32
rtk_vlan_portEgrTagKeepType_set(
    uint32                  unit,
    rtk_port_t              port,
    rtk_vlan_tagKeepType_t  keeptypeOuter,
    rtk_vlan_tagKeepType_t  keeptypeInner)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrTagKeepType_set(unit, phy_port, keeptypeOuter, keeptypeInner);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrTagKeepType_set(unit, port, keeptypeOuter, keeptypeInner);
#endif
} /* end of rtk_vlan_portEgrTagKeepType_set */

/* Function Name:
 *      rtk_vlan_portVlanAggrVidSource_get
 * Description:
 *      Get port ingress learning int address table and egress conversion VID selection inner VID or outer VID.
 * Input:
 *      unit - unit id
 *      port - port id
 * Output:
 *      pSrc - pointer to source selection
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portVlanAggrVidSource_get(uint32 unit, rtk_port_t port, rtk_l2_vlanMode_t *pSrc)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portVlanAggrVidSource_get(unit, phy_port, pSrc);
    }
#else
    return RT_MAPPER(unit)->vlan_portVlanAggrVidSource_get(unit, port, pSrc);
#endif
} /* end of rtk_vlan_portVlanAggrVidSource_get */

/* Function Name:
 *      rtk_vlan_portVlanAggrVidSource_set
 * Description:
 *      Set port ingress learning int address table and egress conversion VID selection inner VID or outer VID.
 * Input:
 *      unit - unit id
 *      port - port id
 *      src  - vlan mode source
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portVlanAggrVidSource_set(uint32 unit, rtk_port_t port, rtk_l2_vlanMode_t src)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portVlanAggrVidSource_set(unit, phy_port, src);
    }
#else
    return RT_MAPPER(unit)->vlan_portVlanAggrVidSource_set(unit, port, src);
#endif
} /* end of rtk_vlan_portVlanAggrVidSource_set */

/* Function Name:
 *      rtk_vlan_portVlanAggrPriTagVidSource_get
 * Description:
 *      Get ingress port priority-tagged packet learning VID.
 * Input:
 *      unit - unit id
 *      port - port id
 * Output:
 *      pSrc - pointer to priority-tagged packet learning VID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_PORT_ID      - invalid port id
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portVlanAggrPriTagVidSource_get(uint32 unit, rtk_port_t port, rtk_vlan_priTagVidSrc_t *pSrc)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portVlanAggrPriTagVidSource_get(unit, phy_port, pSrc);
    }
#else
    return RT_MAPPER(unit)->vlan_portVlanAggrPriTagVidSource_get(unit, port, pSrc);
#endif
} /* end of rtk_vlan_portVlanAggrPriTagVidSource_get */

/* Function Name:
 *      rtk_vlan_portVlanAggrPriTagVidSource_set
 * Description:
 *      Set ingress port priority-tagged packet learning VID 0 or port-based VID.
 * Input:
 *      unit - unit id
 *      port - port id
 *      src  - priority-tagged packet learning VID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_PORT_ID  - invalid port id
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portVlanAggrPriTagVidSource_set(uint32 unit, rtk_port_t port, rtk_vlan_priTagVidSrc_t src)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portVlanAggrPriTagVidSource_set(unit, phy_port, src);
    }
#else
    return RT_MAPPER(unit)->vlan_portVlanAggrPriTagVidSource_set(unit, port, src);
#endif
} /* end of rtk_vlan_portVlanAggrPriTagVidSource_set */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtVidSource_get
 * Description:
 *      Specify the VID source for doing egress VLAN conversion.
 * Input:
 *      unit - unit id
 * Output:
 *      pSrc - pointer to VID source
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrVlanCnvtVidSource_get(uint32 unit, rtk_port_t port, rtk_l2_vlanMode_t *pSrc)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidSource_get(unit, phy_port, pSrc);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidSource_get(unit, port, pSrc);
#endif
} /* end of rtk_vlan_portEgrVlanCnvtVidSource_get */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtVidSource_set
 * Description:
 *      Specify the VID source for doing egress VLAN conversion.
 * Input:
 *      unit - unit id
 *      src  - VID source
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrVlanCnvtVidSource_set(uint32 unit, rtk_port_t port, rtk_l2_vlanMode_t src)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidSource_set(unit, phy_port, src);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidSource_set(unit, port, src);
#endif
} /* end of rtk_vlan_portEgrVlanCnvtVidSource_set */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtVidTarget_get
 * Description:
 *      Specify the VID target for doing egress VLAN conversion.
 * Input:
 *      unit - unit id
 * Output:
 *      pTgt - pointer to VID source
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrVlanCnvtVidTarget_get(uint32 unit, rtk_port_t port, rtk_l2_vlanMode_t *pTgt)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidTarget_get(unit, phy_port, pTgt);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidTarget_get(unit, port, pTgt);
#endif
} /* end of rtk_vlan_portEgrVlanCnvtVidTarget_get */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtVidTarget_set
 * Description:
 *      Specify the VID target for doing egress VLAN conversion.
 * Input:
 *      unit - unit id
 *      tgt  - VID source
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrVlanCnvtVidTarget_set(uint32 unit, rtk_port_t port, rtk_l2_vlanMode_t tgt)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidTarget_set(unit, phy_port, tgt);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtVidTarget_set(unit, port, tgt);
#endif
} /* end of rtk_vlan_portEgrVlanCnvtVidTarget_set */

/* Function Name:
 *      rtk_vlan_portEgrVlanCnvtLookupMissAct_get
 * Description:
 *      Specify egress port VID conversion table lookup miss action.
 * Input:
 *      unit - unit id
 * Output:
 *      pAct - pointer to action selection
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrVlanCnvtLookupMissAct_get(uint32 unit, rtk_port_t port, rtk_vlan_lookupMissAct_t *pAct)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtLookupMissAct_get(unit, phy_port, pAct);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtLookupMissAct_get(unit, port, pAct);
#endif
} /* end of rtk_vlan_portEgrVlanCnvtLookupMissAct_get */

/* Function Name:
 *      rtk_vlan_portEgrVlanCnvtLkmissAct_set
 * Description:
 *      Specify egress port VID conversion table lookup miss action.
 * Input:
 *      unit - unit id
 *      act  - action selection
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 *      RT_ERR_INPUT    - invalid input parameter
 * Applicable:
 *      8380
 * Note:
 *      None
 */
int32
rtk_vlan_portEgrVlanCnvtLookupMissAct_set(uint32 unit, rtk_port_t port, rtk_vlan_lookupMissAct_t act)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

#if defined(CONFIG_SDK_PORT_VIEW_ZERO_BASE_PORT)
    {
    int32  phy_port = RTK_PORT_TO_PHYSICAL_PORT(unit, port);

    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtLookupMissAct_set(unit, phy_port, act);
    }
#else
    return RT_MAPPER(unit)->vlan_portEgrVlanCnvtLookupMissAct_set(unit, port, act);
#endif
} /* end of rtk_vlan_portEgrVlanCnvtLookupMissAct_set */

/* Function Name:
 *      rtk_vlan_igrVlanCnvtEntry_delAll
 * Description:
 *      Delete all ingress VLAN conversion entry.
 * Input:
 *      unit  - unit id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 * Applicable:
 *      8390
 * Note:
 *      All ingress VLAN conversion entries are removed regardless of the operation mode.
 */
int32
rtk_vlan_igrVlanCnvtEntry_delAll(uint32 unit)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_igrVlanCnvtEntry_delAll(unit);
} /* end of rtk_vlan_igrVlanCnvtEntry_delAll */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtEntry_delAll
 * Description:
 *      Delete all egress VLAN conversion entry.
 * Input:
 *      unit  - unit id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID  - invalid unit id
 *      RT_ERR_NOT_INIT - The module is not initial
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_egrVlanCnvtEntry_delAll(uint32 unit)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtEntry_delAll(unit);
} /* end of rtk_vlan_egrVlanCnvtEntry_delAll */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtRangeCheckVid_get
 * Description:
 *      Get the configuration of VID range check for egress VLAN conversion.
 * Input:
 *      unit  - unit id
 *      index - entry index
 * Output:
 *      pData - configuration of VID
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_UNIT_ID      - invalid unit id
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_ENTRY_INDEX  - invalid entry index
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_egrVlanCnvtRangeCheckVid_get(
    uint32                                  unit,
    uint32                                  index,
    rtk_vlan_egrVlanCnvtRangeCheck_vid_t    *pData)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtRangeCheckVid_get(unit, index, pData);
} /* end of rtk_vlan_egrVlanCnvtRangeCheckVid_get */

/* Function Name:
 *      rtk_vlan_egrVlanCnvtRangeCheckVid_set
 * Description:
 *      Set the configuration of VID range check for egress VLAN conversion.
 * Input:
 *      unit  - unit id
 *      index - entry index
 *      pData - configuration of VID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK
 *      RT_ERR_FAILED
 *      RT_ERR_NOT_INIT     - The module is not initial
 *      RT_ERR_ENTRY_INDEX  - invalid entry index
 *      RT_ERR_NULL_POINTER - input parameter may be null pointer
 *      RT_ERR_INPUT        - invalid input parameter
 * Applicable:
 *      8390, 8380
 * Note:
 *      None
 */
int32
rtk_vlan_egrVlanCnvtRangeCheckVid_set(
    uint32                                  unit,
    uint32                                  index,
    rtk_vlan_egrVlanCnvtRangeCheck_vid_t    *pData)
{
    RT_PARAM_CHK((unit > RTK_MAX_UNIT_ID) || NULL == RT_MGMT(unit), RT_ERR_UNIT_ID);

    return RT_MAPPER(unit)->vlan_egrVlanCnvtRangeCheckVid_set(unit, index, pData);
} /* end of rtk_vlan_egrVlanCnvtRangeCheckVid_set */

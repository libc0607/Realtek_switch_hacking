/*
* Copyright (C) 2009 Realtek Semiconductor Corp.
* All Rights Reserved.
*
* This program is the proprietary software of Realtek Semiconductor
* Corporation and/or its licensors, and only be used, duplicated,
* modified or distributed under the authorized license from Realtek.
*
* ANY USE OF THE SOFTWARE OTEHR THAN AS AUTHORIZED UNDER 
* THIS LICENSE OR COPYRIGHT LAW IS PROHIBITED.
* 
* $Revision: 7384 $
* $Date: 2009-12-01 15:33:40 +0800 (Tue, 01 Dec 2009) $
*
* Purpose : ASIC-level driver implementation for Spanning Tree Protocol.
*
*  Feature :  This file consists of following modules:
*             1) 
*
*/

#ifndef __RTL8316D_ASICDRV_STP_H__
#define __RTL8316D_ASICDRV_STP_H__



#endif /*__RTL8316D_ASICDRV_STP_H__*/

